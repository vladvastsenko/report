<?php
/**
 * Template: User Dashboard
 */
if (!defined('ABSPATH')) exit;
?>

<div class="rm-dashboard">
    <header class="rm-dashboard-header">
        <h1><?php _e('Report Manager Dashboard', 'report-manager'); ?></h1>
        <a href="<?php echo home_url('/reports/create/'); ?>" class="rm-button rm-button-primary">
            <?php _e('Create New Report', 'report-manager'); ?>
        </a>
    </header>

    <div class="rm-dashboard-stats">
        <div class="rm-stat-card">
            <div class="rm-stat-number"><?php echo $stats['total_reports']; ?></div>
            <div class="rm-stat-label"><?php _e('Total Reports', 'report-manager'); ?></div>
        </div>
        
        <div class="rm-stat-card">
            <div class="rm-stat-number"><?php echo $stats['reports_this_month']; ?></div>
            <div class="rm-stat-label"><?php _e('This Month', 'report-manager'); ?></div>
        </div>
        
        <div class="rm-stat-card">
            <div class="rm-stat-number"><?php echo $stats['signed_reports']; ?></div>
            <div class="rm-stat-label"><?php _e('Signed Reports', 'report-manager'); ?></div>
        </div>
        
        <div class="rm-stat-card">
            <div class="rm-stat-number"><?php echo $stats['draft_reports']; ?></div>
            <div class="rm-stat-label"><?php _e('Draft Reports', 'report-manager'); ?></div>
        </div>
    </div>

    <div class="rm-dashboard-content">
        <div class="rm-recent-reports">
            <h2><?php _e('Recent Reports', 'report-manager'); ?></h2>
            <?php $this->render_recent_reports($current_user->ID); ?>
        </div>
        
        <div class="rm-user-groups">
            <h2><?php _e('Your Groups', 'report-manager'); ?></h2>
            <?php if ($user_groups): ?>
                <div class="rm-groups-list">
                    <?php foreach ($user_groups as $group): ?>
                        <div class="rm-group-card">
                            <h3><?php echo esc_html($group->name); ?></h3>
                            <p><?php echo esc_html($group->description); ?></p>
                            <div class="rm-group-meta">
                                <span class="rm-group-role"><?php echo ucfirst($group->role); ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p><?php _e('You are not a member of any groups yet.', 'report-manager'); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>