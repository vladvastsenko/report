<?php
/**
 * Template: Report Builder
 */
if (!defined('ABSPATH')) exit;
?>

<div class="rm-report-builder">
    <header class="rm-builder-header">
        <h1><?php _e('Create New Report', 'report-manager'); ?></h1>
        <div class="rm-builder-actions">
            <button type="button" class="rm-button rm-button-secondary" id="rm-save-draft">
                <?php _e('Save Draft', 'report-manager'); ?>
            </button>
            <button type="button" class="rm-button rm-button-primary" id="rm-preview-report">
                <?php _e('Preview', 'report-manager'); ?>
            </button>
        </div>
    </header>

    <div class="rm-builder-container">
        <aside class="rm-builder-sidebar">
            <div class="rm-template-selector">
                <h3><?php _e('Choose Template', 'report-manager'); ?></h3>
                <select id="rm-template-select">
                    <option value=""><?php _e('-- Select Template --', 'report-manager'); ?></option>
                    <?php foreach ($available_templates as $template): ?>
                        <option value="<?php echo $template->id; ?>">
                            <?php echo esc_html($template->name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="rm-project-selector">
                <h3><?php _e('Select Project', 'report-manager'); ?></h3>
                <select id="rm-project-select" name="project_id">
                    <option value=""><?php _e('-- No Project --', 'report-manager'); ?></option>
                    <?php foreach ($projects as $project): ?>
                        <option value="<?php echo $project->id; ?>">
                            <?php echo str_repeat('—', $project->hierarchy_level) . ' ' . esc_html($project->name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="rm-custom-fields">
                <h3><?php _e('Add Custom Field', 'report-manager'); ?></h3>
                <div class="rm-field-types">
                    <button type="button" class="rm-field-type" data-type="text">Text</button>
                    <button type="button" class="rm-field-type" data-type="textarea">Text Area</button>
                    <button type="button" class="rm-field-type" data-type="number">Number</button>
                    <button type="button" class="rm-field-type" data-type="date">Date</button>
                    <button type="button" class="rm-field-type" data-type="image">Image</button>
                </div>
            </div>
        </aside>

        <main class="rm-builder-main">
            <form id="rm-report-form" enctype="multipart/form-data">
                <?php wp_nonce_field('rm_frontend_actions', 'rm_nonce'); ?>
                
                <div class="rm-report-header">
                    <input type="text" name="title" placeholder="<?php esc_attr_e('Report Title', 'report-manager'); ?>" 
                           class="rm-report-title" required>
                    
                    <div class="rm-report-meta">
                        <input type="text" name="address" placeholder="<?php esc_attr_e('Address (optional)', 'report-manager'); ?>"
                               class="rm-report-address">
                    </div>
                </div>

                <div class="rm-form-fields" id="rm-form-fields">
                    <div class="rm-no-fields">
                        <p><?php _e('Select a template or add custom fields to start building your report.', 'report-manager'); ?></p>
                    </div>
                </div>

                <div class="rm-signature-section" style="display: none;">
                    <h3><?php _e('Signature', 'report-manager'); ?></h3>
                    <div class="rm-signature-pad">
                        <canvas id="rm-signature-canvas"></canvas>
                        <div class="rm-signature-actions">
                            <button type="button" id="rm-clear-signature"><?php _e('Clear', 'report-manager'); ?></button>
                        </div>
                        <input type="hidden" name="signature" id="rm-signature-data">
                    </div>
                </div>
            </form>
        </main>
    </div>
</div>