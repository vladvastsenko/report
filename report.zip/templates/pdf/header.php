<?php
/**
 * PDF Header Template
 */
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo esc_html($report->post_title); ?></title>
</head>
<body>
    <header class="pdf-header">
        <?php if ($options['show_logo'] && !empty($options['logo_url'])): ?>
            <div class="logo">
                <img src="<?php echo esc_url($options['logo_url']); ?>" style="max-height: 50px;">
            </div>
        <?php endif; ?>
        
        <div class="header-content">
            <h1><?php echo esc_html($report->post_title); ?></h1>
            <div class="report-meta">
                <p><strong><?php _e('Date:', 'report-manager'); ?></strong> <?php echo date_i18n(get_option('date_format'), strtotime($report->post_date)); ?></p>
                <p><strong><?php _e('Author:', 'report-manager'); ?></strong> <?php echo get_the_author_meta('display_name', $report->post_author); ?></p>
                
                <?php if ($address = get_post_meta($report->ID, '_rm_report_address', true)): ?>
                    <p><strong><?php _e('Address:', 'report-manager'); ?></strong> <?php echo esc_html($address); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </header>