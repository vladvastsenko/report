(function($) {
    'use strict';

    class PDFExport {
        constructor() {
            this.init();
        }

        init() {
            this.bindEvents();
        }

        bindEvents() {
            // Экспорт отчета
            $(document).on('click', '.rm-export-pdf', (e) => this.exportReport(e, 'pdf'));
            $(document).on('click', '.rm-export-csv', (e) => this.exportReport(e, 'csv'));
            $(document).on('click', '.rm-export-json', (e) => this.exportReport(e, 'json'));
            
            // Временная ссылка
            $(document).on('click', '.rm-generate-link', (e) => this.generateTemporaryLink(e));
            
            // Отправка email
            $(document).on('click', '.rm-send-email', (e) => this.sendEmail(e));
        }

        exportReport(e, format) {
            e.preventDefault();
            
            const $button = $(e.target);
            const reportId = $button.data('report-id');
            
            $button.prop('disabled', true).text(rm_frontend.i18n.saving);
            
            $.ajax({
                url: rm_frontend.ajax_url,
                type: 'POST',
                data: {
                    action: 'rm_export_report',
                    report_id: reportId,
                    format: format,
                    nonce: rm_frontend.nonce
                },
                success: (response) => {
                    if (response.success) {
                        // Скачиваем файл
                        window.location.href = response.data.download_url;
                    } else {
                        this.showMessage(response.data, 'error');
                    }
                },
                error: () => {
                    this.showMessage(rm_frontend.i18n.error, 'error');
                },
                complete: () => {
                    $button.prop('disabled', false).text(this.getButtonText(format));
                }
            });
        }

        generateTemporaryLink(e) {
            e.preventDefault();
            
            const $button = $(e.target);
            const reportId = $button.data('report-id');
            const expiryHours = 24; // Можно сделать настраиваемым
            
            $button.prop('disabled', true).text(rm_frontend.i18n.generating);
            
            $.ajax({
                url: rm_frontend.ajax_url,
                type: 'POST',
                data: {
                    action: 'rm_generate_temporary_link',
                    report_id: reportId,
                    expiry_hours: expiryHours,
                    nonce: rm_frontend.nonce
                },
                success: (response) => {
                    if (response.success) {
                        this.showTemporaryLink(response.data.link, expiryHours);
                    } else {
                        this.showMessage(response.data, 'error');
                    }
                },
                error: () => {
                    this.showMessage(rm_frontend.i18n.error, 'error');
                },
                complete: () => {
                    $button.prop('disabled', false).text(rm_frontend.i18n.generate_link);
                }
            });
        }

        showTemporaryLink(link, expiryHours) {
            const $modal = $(`
                <div class="rm-modal">
                    <div class="rm-modal-content">
                        <h3>${rm_frontend.i18n.temporary_link}</h3>
                        <p>${rm_frontend.i18n.link_expires.replace('{{hours}}', expiryHours)}</p>
                        <input type="text" value="${link}" readonly class="rm-link-input">
                        <button type="button" class="rm-copy-link">${rm_frontend.i18n.copy_link}</button>
                        <button type="button" class="rm-close-modal">${rm_frontend.i18n.close}</button>
                    </div>
                </div>
            `);
            
            $('body').append($modal);
            
            $modal.find('.rm-copy-link').on('click', () => {
                const $input = $modal.find('.rm-link-input');
                $input.select();
                document.execCommand('copy');
                this.showMessage(rm_frontend.i18n.link_copied, 'success');
            });
            
            $modal.find('.rm-close-modal').on('click', () => {
                $modal.remove();
            });
        }

        getButtonText(format) {
            const texts = {
                pdf: rm_frontend.i18n.export_pdf,
                csv: rm_frontend.i18n.export_csv,
                json: rm_frontend.i18n.export_json
            };
            
            return texts[format] || rm_frontend.i18n.export;
        }

        showMessage(message, type) {
            // Реализация показа сообщений (как в предыдущем коде)
        }
    }

    $(document).ready(() => {
        new PDFExport();
    });

})(jQuery);