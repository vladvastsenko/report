(function($) {
    'use strict';

    class TaskManager {
        constructor() {
            this.init();
        }

        init() {
            this.bindEvents();
            this.initModals();
        }

        bindEvents() {
            // Создание задачи
            $(document).on('click', '#rm-create-task', () => this.showCreateTaskModal());
            
            // Изменение статуса
            $(document).on('click', '.rm-change-status', (e) => this.changeTaskStatus(e));
            
            // Сохранение задачи
            $(document).on('submit', '#rm-task-form', (e) => this.saveTask(e));
            
            // Закрытие модальных окон
            $(document).on('click', '.rm-close-modal, .rm-modal-overlay', (e) => this.closeModal(e));
        }

        showCreateTaskModal() {
            $('#rm-create-task-modal').show();
        }

        changeTaskStatus(e) {
            const $button = $(e.target);
            const taskId = $button.data('task-id');
            const currentStatus = $button.data('current-status');
            
            const statusOptions = {
                pending: ['in_progress', 'completed'],
                in_progress: ['review', 'completed', 'pending'],
                review: ['completed', 'in_progress'],
                completed: ['in_progress', 'pending']
            };
            
            const availableStatuses = statusOptions[currentStatus] || [];
            
            if (availableStatuses.length === 0) {
                this.showMessage('No available status changes', 'error');
                return;
            }
            
            const statusHtml = availableStatuses.map(status => 
                `<option value="${status}">${this.getStatusLabel(status)}</option>`
            ).join('');
            
            const modalHtml = `
                <div class="rm-modal">
                    <div class="rm-modal-content">
                        <h3>Change Task Status</h3>
                        <select id="rm-new-status">${statusHtml}</select>
                        <div class="rm-modal-actions">
                            <button type="button" class="rm-button rm-confirm-status">Confirm</button>
                            <button type="button" class="rm-button rm-button-secondary rm-close-modal">Cancel</button>
                        </div>
                    </div>
                </div>
            `;
            
            $('body').append(modalHtml);
            
            $('.rm-confirm-status').on('click', () => {
                const newStatus = $('#rm-new-status').val();
                this.updateTaskStatus(taskId, newStatus);
                $('.rm-modal').remove();
            });
        }

        updateTaskStatus(taskId, newStatus) {
            $.ajax({
                url: rm_frontend.ajax_url,
                type: 'POST',
                data: {
                    action: 'rm_change_task_status',
                    task_id: taskId,
                    status: newStatus,
                    nonce: rm_frontend.nonce
                },
                success: (response) => {
                    if (response.success) {
                        this.showMessage('Task status updated', 'success');
                        // Обновляем интерфейс
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        this.showMessage(response.data, 'error');
                    }
                },
                error: () => {
                    this.showMessage('Error updating task status', 'error');
                }
            });
        }

        saveTask(e) {
            e.preventDefault();
            
            const $form = $(e.target);
            const formData = new FormData($form[0]);
            formData.append('action', 'rm_create_task');
            formData.append('nonce', rm_frontend.nonce);
            
            $.ajax({
                url: rm_frontend.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: (response) => {
                    if (response.success) {
                        this.showMessage('Task created successfully', 'success');
                        this.closeModal();
                        setTimeout(() => location.reload(), 1000);
                    } else {
                        this.showMessage(response.data, 'error');
                    }
                },
                error: () => {
                    this.showMessage('Error creating task', 'error');
                }
            });
        }

        getStatusLabel(status) {
            const labels = {
                pending: 'Pending',
                in_progress: 'In Progress',
                review: 'Under Review',
                completed: 'Completed'
            };
            
            return labels[status] || status;
        }

        showMessage(message, type) {
            // Реализация показа сообщений
        }

        closeModal() {
            $('.rm-modal').hide();
        }

        initModals() {
            // Инициализация модальных окон
        }
    }

    $(document).ready(() => {
        new TaskManager();
    });

})(jQuery);