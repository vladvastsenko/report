<?php

class RM_Export_Handler {
    
    public function __construct() {
        add_action('wp_ajax_rm_export_report', array($this, 'ajax_export_report'));
        add_action('wp_ajax_rm_generate_temporary_link', array($this, 'ajax_generate_temporary_link'));
        add_action('init', array($this, 'handle_pdf_requests'));
    }
    
    /**
     * Обработка запросов PDF
     */
    public function handle_pdf_requests() {
        if (isset($_GET['rm_pdf'])) {
            $pdf_generator = new RM_PDF_Generator();
            $pdf_generator->handle_temporary_link(sanitize_text_field($_GET['rm_pdf']));
        }
        
        if (isset($_GET['rm_export']) && $_GET['rm_export'] === 'pdf') {
            $this->handle_direct_export();
        }
    }
    
    /**
     * Прямой экспорт PDF
     */
    private function handle_direct_export() {
        if (!is_user_logged_in()) {
            auth_redirect();
        }
        
        $report_id = isset($_GET['report_id']) ? intval($_GET['report_id']) : 0;
        
        if (!$report_id || !$this->user_can_export_report(get_current_user_id(), $report_id)) {
            wp_die(__('You do not have permission to export this report', 'report-manager'));
        }
        
        $pdf_generator = new RM_PDF_Generator();
        $pdf_data = $pdf_generator->generate_report_pdf($report_id);
        
        if ($pdf_data && file_exists($pdf_data['filepath'])) {
            $pdf_generator->force_download($pdf_data['filepath'], $pdf_data['filename']);
        } else {
            wp_die(__('Failed to generate PDF', 'report-manager'));
        }
    }
    
    /**
     * AJAX: Экспорт отчета
     */
    public function ajax_export_report() {
        check_ajax_referer('rm_frontend_actions', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(__('Authentication required', 'report-manager'));
        }
        
        $report_id = intval($_POST['report_id']);
        $format = sanitize_text_field($_POST['format']);
        
        if (!$this->user_can_export_report(get_current_user_id(), $report_id)) {
            wp_send_json_error(__('Permission denied', 'report-manager'));
        }
        
        switch ($format) {
            case 'pdf':
                $result = $this->export_to_pdf($report_id);
                break;
                
            case 'csv':
                $result = $this->export_to_csv($report_id);
                break;
                
            case 'json':
                $result = $this->export_to_json($report_id);
                break;
                
            default:
                wp_send_json_error(__('Unsupported export format', 'report-manager'));
        }
        
        if ($result) {
            wp_send_json_success(array(
                'message' => __('Export completed successfully', 'report-manager'),
                'download_url' => $result['url'] ?? '',
                'filename' => $result['filename'] ?? ''
            ));
        } else {
            wp_send_json_error(__('Export failed', 'report-manager'));
        }
    }
    
    /**
     * Экспорт в PDF
     */
    private function export_to_pdf($report_id) {
        $pdf_generator = new RM_PDF_Generator();
        return $pdf_generator->generate_report_pdf($report_id);
    }
    
    /**
     * Экспорт в CSV
     */
    private function export_to_csv($report_id) {
        $report = get_post($report_id);
        $report_data = get_post_meta($report_id, '_rm_report_data', true);
        
        // Создаем CSV содержимое
        $csv_data = array();
        $csv_data[] = array('Field', 'Value');
        $csv_data[] = array('Title', $report->post_title);
        $csv_data[] = array('Date', $report->post_date);
        
        foreach ($report_data as $field => $value) {
            if (is_array($value)) {
                $value = implode(', ', $value);
            }
            $csv_data[] = array($field, $value);
        }
        
        // Генерируем CSV строку
        $csv_content = '';
        foreach ($csv_data as $row) {
            $csv_content .= '"' . implode('","', $row) . '"' . "\n";
        }
        
        // Сохраняем во временный файл
        $filename = 'report_' . $report_id . '_' . current_time('Y-m-d') . '.csv';
        $filepath = WP_CONTENT_DIR . '/uploads/rm_export/' . $filename;
        
        wp_mkdir_p(dirname($filepath));
        file_put_contents($filepath, $csv_content);
        
        return array(
            'filepath' => $filepath,
            'filename' => $filename,
            'url' => wp_upload_dir()['baseurl'] . '/rm_export/' . $filename
        );
    }
    
    /**
     * Экспорт в JSON
     */
    private function export_to_json($report_id) {
        $report = get_post($report_id);
        $report_data = get_post_meta($report_id, '_rm_report_data', true);
        
        $export_data = array(
            'id' => $report_id,
            'title' => $report->post_title,
            'date' => $report->post_date,
            'author' => get_the_author_meta('display_name', $report->post_author),
            'data' => $report_data
        );
        
        $json_content = json_encode($export_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        
        $filename = 'report_' . $report_id . '_' . current_time('Y-m-d') . '.json';
        $filepath = WP_CONTENT_DIR . '/uploads/rm_export/' . $filename;
        
        wp_mkdir_p(dirname($filepath));
        file_put_contents($filepath, $json_content);
        
        return array(
            'filepath' => $filepath,
            'filename' => $filename,
            'url' => wp_upload_dir()['baseurl'] . '/rm_export/' . $filename
        );
    }
    
    /**
     * AJAX: Генерация временной ссылки
     */
    public function ajax_generate_temporary_link() {
        check_ajax_referer('rm_frontend_actions', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(__('Authentication required', 'report-manager'));
        }
        
        $report_id = intval($_POST['report_id']);
        $expiry_hours = intval($_POST['expiry_hours'] ?? 24);
        
        if (!$this->user_can_export_report(get_current_user_id(), $report_id)) {
            wp_send_json_error(__('Permission denied', 'report-manager'));
        }
        
        $pdf_generator = new RM_PDF_Generator();
        $temporary_link = $pdf_generator->generate_temporary_link($report_id, $expiry_hours);
        
        if ($temporary_link) {
            wp_send_json_success(array(
                'message' => __('Temporary link generated', 'report-manager'),
                'link' => $temporary_link,
                'expires' => $expiry_hours
            ));
        } else {
            wp_send_json_error(__('Failed to generate temporary link', 'report-manager'));
        }
    }
    
    /**
     * Проверка прав на экспорт
     */
    private function user_can_export_report($user_id, $report_id) {
        // Автор может экспортировать свой отчет
        $report_author = get_post_field('post_author', $report_id);
        if ($report_author == $user_id) {
            return true;
        }
        
        // Суперпользователь группы может экспортировать отчеты своей группы
        $groups = new RM_Groups();
        $user_groups = $groups->get_user_groups($user_id, 'super_user');
        
        foreach ($user_groups as $group) {
            $report_group = get_post_meta($report_id, '_rm_report_group', true);
            if ($report_group == $group->id) {
                return true;
            }
        }
        
        return false;
    }
}