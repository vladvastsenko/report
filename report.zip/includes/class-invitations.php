<?php

class RM_Invitations {
    
    public function __construct() {
        add_action('wp_ajax_rm_send_invitation', array($this, 'ajax_send_invitation'));
        add_action('wp_ajax_rm_resend_invitation', array($this, 'ajax_resend_invitation'));
        add_action('wp_ajax_rm_cancel_invitation', array($this, 'ajax_cancel_invitation'));
        
        // Хук для обработки регистрации по приглашению
        add_action('user_register', array($this, 'handle_user_registration'), 10, 1);
    }
    
    /**
     * Отправка приглашения по email
     */
    public function send_invitation($email, $group_id, $invited_by) {
        global $wpdb;
        
        // Проверяем существует ли уже пользователь с таким email
        $user = get_user_by('email', $email);
        
        if ($user) {
            // Пользователь существует - добавляем в группу
            $groups = new RM_Groups();
            return $groups->add_user_to_group($user->ID, $group_id, 'user', $invited_by);
        } else {
            // Пользователь не существует - создаем приглашение
            $invitation_token = wp_generate_password(32, false);
            
            $result = $wpdb->insert(
                $wpdb->prefix . 'rm_invitations',
                array(
                    'email' => sanitize_email($email),
                    'group_id' => $group_id,
                    'invited_by' => $invited_by,
                    'token' => $invitation_token,
                    'status' => 'pending',
                    'created_at' => current_time('mysql'),
                    'expires_at' => date('Y-m-d H:i:s', strtotime('+7 days'))
                ),
                array('%s', '%d', '%d', '%s', '%s', '%s', '%s')
            );
            
            if ($result) {
                return $this->send_invitation_email($email, $invitation_token, $group_id);
            }
        }
        
        return false;
    }
    
    /**
     * Отправка email с приглашением
     */
    private function send_invitation_email($email, $token, $group_id) {
        $invitation_url = add_query_arg(array(
            'rm_invite' => $token,
            'group' => $group_id
        ), wp_registration_url());
        
        $subject = __('Invitation to join report system', 'report-manager');
        $message = sprintf(__(
            'You have been invited to join our reporting system. ' .
            'Click the link below to register: %s', 
            'report-manager'
        ), $invitation_url);
        
        $headers = array('Content-Type: text/html; charset=UTF-8');
        
        return wp_mail($email, $subject, $message, $headers);
    }
    
    /**
     * Обработка регистрации пользователя по приглашению
     */
    public function handle_user_registration($user_id) {
        if (!isset($_GET['rm_invite']) || !isset($_GET['group'])) {
            return;
        }
        
        $token = sanitize_text_field($_GET['rm_invite']);
        $group_id = intval($_GET['group']);
        
        global $wpdb;
        
        // Проверяем приглашение
        $invitation = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}rm_invitations 
             WHERE token = %s AND group_id = %d AND status = 'pending' AND expires_at > %s",
            $token, $group_id, current_time('mysql')
        ));
        
        if ($invitation) {
            // Добавляем пользователя в группу
            $groups = new RM_Groups();
            $groups->add_user_to_group($user_id, $group_id, 'user', $invitation->invited_by);
            
            // Помечаем приглашение как использованное
            $wpdb->update(
                $wpdb->prefix . 'rm_invitations',
                array('status' => 'accepted', 'accepted_at' => current_time('mysql')),
                array('id' => $invitation->id),
                array('%s', '%s'),
                array('%d')
            );
        }
    }
    
    /**
     * AJAX: Отправка приглашения
     */
    public function ajax_send_invitation() {
        check_ajax_referer('rm_manage_groups', 'nonce');
        
        if (!current_user_can('rm_invite_users')) {
            wp_die(__('Insufficient permissions', 'report-manager'));
        }
        
        $email = sanitize_email($_POST['email']);
        $group_id = intval($_POST['group_id']);
        $user_id = get_current_user_id();
        
        if (!is_email($email)) {
            wp_send_json_error(__('Invalid email address', 'report-manager'));
        }
        
        $result = $this->send_invitation($email, $group_id, $user_id);
        
        if ($result) {
            wp_send_json_success(__('Invitation sent successfully', 'report-manager'));
        } else {
            wp_send_json_error(__('Failed to send invitation', 'report-manager'));
        }
    }
}