<?php

class RM_PMPro_Integration {
    
    public function __construct() {
        add_action('pmpro_after_checkout', array($this, 'handle_pmpro_checkout'), 10, 2);
        add_action('pmpro_subscription_expired', array($this, 'handle_subscription_expired'));
        add_action('pmpro_before_change_membership_level', array($this, 'handle_level_change'), 10, 4);
        add_filter('pmpro_has_membership_access_filter', array($this, 'check_report_access'), 10, 4);
        
        // Проверка trial периода
        add_action('wp', array($this, 'check_trial_status'));
    }
    
    /**
     * Обработка успешной регистрации/покупки
     */
    public function handle_pmpro_checkout($user_id, $level) {
        $trial_days = 14; // Ознакомительный период
        
        // Устанавливаем дату окончания trial
        update_user_meta($user_id, 'rm_trial_end', date('Y-m-d H:i:s', strtotime("+{$trial_days} days")));
        update_user_meta($user_id, 'rm_trial_used', false);
        
        // Если пользователь сам зарегистрировался - создаем для него группу
        if (!$this->user_has_group($user_id)) {
            $this->create_user_group($user_id);
        }
    }
    
    /**
     * Создание группы для нового пользователя
     */
    private function create_user_group($user_id) {
        global $wpdb;
        
        $user = get_userdata($user_id);
        $group_name = sprintf(__("%s's Group", 'report-manager'), $user->display_name);
        
        $wpdb->insert(
            $wpdb->prefix . 'rm_groups',
            array(
                'name' => $group_name,
                'super_user_id' => $user_id,
                'allow_custom_pdf' => 1,
                'created_at' => current_time('mysql')
            )
        );
        
        $group_id = $wpdb->insert_id;
        
        // Добавляем пользователя в группу как суперпользователя
        $wpdb->insert(
            $wpdb->prefix . 'rm_user_groups',
            array(
                'user_id' => $user_id,
                'group_id' => $group_id,
                'role' => 'super_user',
                'joined_at' => current_time('mysql')
            )
        );
        
        // Обновляем роль пользователя в WordPress
        $user->remove_role('subscriber');
        $user->add_role('rm_super_user');
        
        return $group_id;
    }
    
    /**
     * Проверка trial статуса пользователя
     */
    public function check_trial_status() {
        if (!is_user_logged_in()) return;
        
        $user_id = get_current_user_id();
        $trial_end = get_user_meta($user_id, 'rm_trial_end', true);
        $trial_used = get_user_meta($user_id, 'rm_trial_used', true);
        
        // Если trial еще не использован и время вышло
        if (!$trial_used && $trial_end && strtotime($trial_end) < time()) {
            $this->handle_trial_expired($user_id);
        }
    }
    
    /**
     * Обработка окончания trial периода
     */
    private function handle_trial_expired($user_id) {
        update_user_meta($user_id, 'rm_trial_used', true);
        
        // Показываем уведомление о необходимости подписки
        if (!pmpro_hasMembershipLevel()) {
            // Можно добавить редирект на страницу подписки
            // или показать сообщение
        }
    }
    
    /**
     * Проверка доступа к отчетам
     */
    public function check_report_access($hasaccess, $post, $user, $levels) {
        // Если это наш тип записи отчета
        if ($post->post_type === 'rm_report') {
            $hasaccess = $this->user_can_access_report($user->ID, $post->ID);
        }
        
        return $hasaccess;
    }
    
    /**
     * Проверка может ли пользователь получить доступ к отчету
     */
    private function user_can_access_report($user_id, $report_id) {
        // Логика проверки доступа к отчету
        // (будет дополнена на следующих этапах)
        return true;
    }
    
    private function user_has_group($user_id) {
        global $wpdb;
        $table = $wpdb->prefix . 'rm_user_groups';
        
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE user_id = %d",
            $user_id
        ));
        
        return $count > 0;
    }
}