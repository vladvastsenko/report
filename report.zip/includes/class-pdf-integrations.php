<?php

class RM_PDF_Integrations {
    
    private $available_plugins = array();
    private $active_plugin = null;
    
    public function __construct() {
        $this->detect_available_plugins();
        $this->set_active_plugin();
    }
    
    /**
     * Обнаружение установленных PDF плагинов
     */
    public function detect_available_plugins() {
        $this->available_plugins = array();
        
        // 1. PDF Generator for WP
        if (class_exists('PDF_Generator_For_WP') || function_exists('pdfgfw_generate_pdf')) {
            $this->available_plugins['pdf_generator_wp'] = array(
                'name' => 'PDF Generator for WP',
                'type' => 'class',
                'generate_method' => 'generate_pdf',
                'supported' => true
            );
        }
        
        // 2. DK PDF
        if (function_exists('dkpdf') || shortcode_exists('dkpdf')) {
            $this->available_plugins['dk_pdf'] = array(
                'name' => 'DK PDF', 
                'type' => 'function',
                'generate_method' => 'generate_pdf',
                'supported' => true
            );
        }
        
        // 3. WP HTML to PDF
        if (function_exists('wp_html_to_pdf')) {
            $this->available_plugins['wp_html_to_pdf'] = array(
                'name' => 'WP HTML to PDF',
                'type' => 'function', 
                'generate_method' => 'wp_html_to_pdf',
                'supported' => true
            );
        }
        
        // 4. Print, PDF, Email by PrintFriendly
        if (class_exists('PrintFriendly_WordPress')) {
            $this->available_plugins['printfriendly'] = array(
                'name' => 'Print, PDF, Email by PrintFriendly',
                'type' => 'class',
                'supported' => true
            );
        }
        
        // 5. WooCommerce PDF Invoices (если используется WooCommerce)
        if (class_exists('WooCommerce') && class_exists('WC_PDF_Invoices')) {
            $this->available_plugins['wc_pdf_invoices'] = array(
                'name' => 'WooCommerce PDF Invoices',
                'type' => 'class',
                'supported' => true
            );
        }
        
        // 6. Easy PDF Generator
        if (function_exists('easy_pdf_generator')) {
            $this->available_plugins['easy_pdf'] = array(
                'name' => 'Easy PDF Generator',
                'type' => 'function',
                'supported' => true
            );
        }
    }
    
    /**
     * Установка активного плагина
     */
    private function set_active_plugin() {
        $preferred_plugin = get_option('rm_preferred_pdf_plugin', 'auto');
        
        if ($preferred_plugin !== 'auto' && isset($this->available_plugins[$preferred_plugin])) {
            $this->active_plugin = $preferred_plugin;
        } else {
            // Автовыбор первого доступного плагина
            $this->active_plugin = !empty($this->available_plugins) ? 
                key($this->available_plugins) : null;
        }
    }
    
    /**
     * Генерация PDF через активный плагин
     */
    public function generate_pdf($html_content, $options = array()) {
        if (!$this->active_plugin) {
            return $this->fallback_generation($html_content, $options);
        }
        
        $plugin = $this->available_plugins[$this->active_plugin];
        
        switch ($this->active_plugin) {
            case 'pdf_generator_wp':
                return $this->generate_with_pdf_generator_wp($html_content, $options);
                
            case 'dk_pdf':
                return $this->generate_with_dkpdf($html_content, $options);
                
            case 'wp_html_to_pdf':
                return $this->generate_with_wp_html_to_pdf($html_content, $options);
                
            case 'printfriendly':
                return $this->generate_with_printfriendly($html_content, $options);
                
            default:
                return $this->fallback_generation($html_content, $options);
        }
    }
    
    /**
     * Генерация через PDF Generator for WP
     */
    private function generate_with_pdf_generator_wp($html_content, $options) {
        try {
            // Создаем временный файл
            $upload_dir = wp_upload_dir();
            $temp_html_file = $upload_dir['path'] . '/rm_temp_' . uniqid() . '.html';
            file_put_contents($temp_html_file, $html_content);
            
            // Пытаемся использовать методы плагина
            if (class_exists('PDF_Generator_For_WP')) {
                $pdf_generator = PDF_Generator_For_WP::get_instance();
                if (method_exists($pdf_generator, 'generate_pdf')) {
                    $pdf_path = $pdf_generator->generate_pdf($temp_html_file, $options);
                }
            }
            
            // Альтернативный метод через функцию
            if (empty($pdf_path) && function_exists('pdfgfw_generate_pdf')) {
                $pdf_path = pdfgfw_generate_pdf($temp_html_file, $options);
            }
            
            // Очистка временного файла
            if (file_exists($temp_html_file)) {
                unlink($temp_html_file);
            }
            
            if (!empty($pdf_path) && file_exists($pdf_path)) {
                return array(
                    'success' => true,
                    'filepath' => $pdf_path,
                    'filename' => basename($pdf_path),
                    'url' => str_replace($upload_dir['basedir'], $upload_dir['baseurl'], $pdf_path),
                    'engine' => 'PDF Generator for WP'
                );
            }
        } catch (Exception $e) {
            error_log('Report Manager - PDF Generator for WP Error: ' . $e->getMessage());
        }
        
        return false;
    }
    
    /**
     * Генерация через DK PDF
     */
    private function generate_with_dkpdf($html_content, $options) {
        try {
            // Создаем временный пост для генерации PDF
            $temp_post_id = wp_insert_post(array(
                'post_title' => 'Report PDF - ' . current_time('Y-m-d H:i:s'),
                'post_content' => $html_content,
                'post_status' => 'publish',
                'post_type' => 'rm_temp_pdf'
            ));
            
            if ($temp_post_id && !is_wp_error($temp_post_id)) {
                
                // Метод 1: Через функцию dkpdf
                if (function_exists('dkpdf')) {
                    $pdf_url = dkpdf($temp_post_id);
                }
                
                // Метод 2: Через шорткод
                if (empty($pdf_url) && shortcode_exists('dkpdf')) {
                    $pdf_url = do_shortcode("[dkpdf url='".get_permalink($temp_post_id)."']");
                }
                
                // Метод 3: Через прямую генерацию
                if (empty($pdf_url)) {
                    $pdf_url = site_url("/?p=$temp_post_id&dkpdf=1");
                }
                
                if (!empty($pdf_url)) {
                    $upload_dir = wp_upload_dir();
                    $pdf_filename = 'report_' . $temp_post_id . '.pdf';
                    $pdf_path = $upload_dir['path'] . '/' . $pdf_filename;
                    
                    // Скачиваем PDF по URL
                    $response = wp_remote_get($pdf_url);
                    
                    if (!is_wp_error($response) && $response['response']['code'] === 200) {
                        file_put_contents($pdf_path, $response['body']);
                        
                        // Удаляем временный пост
                        wp_delete_post($temp_post_id, true);
                        
                        return array(
                            'success' => true,
                            'filepath' => $pdf_path,
                            'filename' => $pdf_filename,
                            'url' => $upload_dir['url'] . '/' . $pdf_filename,
                            'engine' => 'DK PDF'
                        );
                    }
                }
                
                // Удаляем временный пост в случае ошибки
                wp_delete_post($temp_post_id, true);
            }
        } catch (Exception $e) {
            error_log('Report Manager - DK PDF Error: ' . $e->getMessage());
        }
        
        return false;
    }
    
    /**
     * Генерация через WP HTML to PDF
     */
    private function generate_with_wp_html_to_pdf($html_content, $options) {
        try {
            $pdf_data = wp_html_to_pdf($html_content, $options);
            
            if ($pdf_data && isset($pdf_data['file']) && file_exists($pdf_data['file'])) {
                return array(
                    'success' => true,
                    'filepath' => $pdf_data['file'],
                    'filename' => basename($pdf_data['file']),
                    'url' => $pdf_data['url'] ?? '',
                    'engine' => 'WP HTML to PDF'
                );
            }
        } catch (Exception $e) {
            error_log('Report Manager - WP HTML to PDF Error: ' . $e->getMessage());
        }
        
        return false;
    }
    
    /**
     * Генерация через PrintFriendly
     */
    private function generate_with_printfriendly($html_content, $options) {
        try {
            // PrintFriendly обычно работает через API
            // Создаем временный файл и используем их сервис
            $upload_dir = wp_upload_dir();
            $temp_html_file = $upload_dir['path'] . '/rm_temp_' . uniqid() . '.html';
            file_put_contents($temp_html_file, $html_content);
            
            $temp_html_url = str_replace($upload_dir['basedir'], $upload_dir['baseurl'], $temp_html_file);
            
            // Генерируем PDF через их сервис
            $api_url = 'https://cdn.printfriendly.com/pdf/generate?url=' . urlencode($temp_html_url);
            $response = wp_remote_get($api_url);
            
            if (!is_wp_error($response) && $response['response']['code'] === 200) {
                $pdf_filename = 'report_printfriendly_' . uniqid() . '.pdf';
                $pdf_path = $upload_dir['path'] . '/' . $pdf_filename;
                file_put_contents($pdf_path, $response['body']);
                
                // Удаляем временный HTML файл
                unlink($temp_html_file);
                
                return array(
                    'success' => true,
                    'filepath' => $pdf_path,
                    'filename' => $pdf_filename,
                    'url' => $upload_dir['url'] . '/' . $pdf_filename,
                    'engine' => 'PrintFriendly'
                );
            }
            
            // Очистка в случае ошибки
            if (file_exists($temp_html_file)) {
                unlink($temp_html_file);
            }
            
        } catch (Exception $e) {
            error_log('Report Manager - PrintFriendly Error: ' . $e->getMessage());
        }
        
        return false;
    }
    
    /**
     * Резервная генерация через DomPDF
     */
    private function fallback_generation($html_content, $options) {
        $pdf_generator = new RM_PDF_Fallback();
        return $pdf_generator->generate_pdf($html_content, $options);
    }
    
    /**
     * Получение активного плагина
     */
    public function get_active_plugin() {
        return $this->active_plugin ? $this->available_plugins[$this->active_plugin] : null;
    }
    
    /**
     * Получение списка доступных плагинов
     */
    public function get_available_plugins() {
        return $this->available_plugins;
    }
    
    /**
     * Проверка наличия PDF плагинов
     */
    public function has_pdf_plugins() {
        return !empty($this->available_plugins);
    }
    
    /**
     * Установка предпочтительного плагина
     */
    public function set_preferred_plugin($plugin_slug) {
        if (array_key_exists($plugin_slug, $this->available_plugins) || $plugin_slug === 'dompdf') {
            update_option('rm_preferred_pdf_plugin', $plugin_slug);
            $this->active_plugin = $plugin_slug === 'dompdf' ? null : $plugin_slug;
            return true;
        }
        return false;
    }
}