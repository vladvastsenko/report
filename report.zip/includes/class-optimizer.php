<?php

class RM_Optimizer {
    
    public function __construct() {
        add_action('wp_enqueue_scripts', array($this, 'optimize_assets'));
        add_action('admin_enqueue_scripts', array($this, 'optimize_admin_assets'));
        add_action('wp_head', array($this, 'add_meta_tags'));
        add_action('init', array($this, 'register_cron_jobs'));
        add_action('rm_daily_maintenance', array($this, 'daily_maintenance'));
    }
    
    /**
     * Оптимизация фронтенд ассетов
     */
    public function optimize_assets() {
        // Объединение и минификация в продакшене
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $css_suffix = '';
            $js_suffix = '';
        } else {
            $css_suffix = '.min';
            $js_suffix = '.min';
        }
        
        // Загрузка только на нужных страницах
        if (!$this->is_rm_page()) {
            return;
        }
        
        // CSS ассеты
        wp_enqueue_style(
            'rm-frontend-all',
            RM_PLUGIN_URL . 'assets/css/frontend-all' . $css_suffix . '.css',
            array(),
            RM_PLUGIN_VERSION
        );
        
        // JS ассеты
        wp_enqueue_script(
            'rm-frontend-all',
            RM_PLUGIN_URL . 'assets/js/frontend-all' . $js_suffix . '.js',
            array('jquery', 'jquery-ui-sortable'),
            RM_PLUGIN_VERSION,
            true
        );
    }
    
    /**
     * Оптимизация админ ассетов
     */
    public function optimize_admin_assets($hook) {
        if (strpos($hook, 'report-manager') === false) {
            return;
        }
        
        wp_enqueue_style(
            'rm-admin-all',
            RM_PLUGIN_URL . 'assets/css/admin-all.min.css',
            array(),
            RM_PLUGIN_VERSION
        );
        
        wp_enqueue_script(
            'rm-admin-all',
            RM_PLUGIN_URL . 'assets/js/admin-all.min.js',
            array('jquery', 'jquery-ui-sortable'),
            RM_PLUGIN_VERSION,
            true
        );
    }
    
    /**
     * Добавление meta тегов
     */
    public function add_meta_tags() {
        if (!$this->is_rm_page()) {
            return;
        }
        
        echo '<meta name="report-manager-version" content="' . RM_PLUGIN_VERSION . '">' . "\n";
        echo '<meta name="generator" content="Report Manager ' . RM_PLUGIN_VERSION . '">' . "\n";
    }
    
    /**
     * Регистрация cron задач
     */
    public function register_cron_jobs() {
        if (!wp_next_scheduled('rm_daily_maintenance')) {
            wp_schedule_event(time(), 'daily', 'rm_daily_maintenance');
        }
        
        if (!wp_next_scheduled('rm_cleanup_temp_files')) {
            wp_schedule_event(time(), 'twicedaily', 'rm_cleanup_temp_files');
        }
    }
    
    /**
     * Ежедневное обслуживание
     */
    public function daily_maintenance() {
        $this->cleanup_old_temp_files();
        $this->check_expired_temporary_links();
        $this->send_daily_digest();
        $this->optimize_database_tables();
    }
    
    /**
     * Очистка временных файлов
     */
    private function cleanup_old_temp_files() {
        $temp_dirs = array(
            WP_CONTENT_DIR . '/uploads/rm_pdf/',
            WP_CONTENT_DIR . '/uploads/rm_export/'
        );
        
        $max_age = 24 * 60 * 60; // 24 часа
        
        foreach ($temp_dirs as $dir) {
            if (!is_dir($dir)) continue;
            
            $files = glob($dir . '*');
            $now = time();
            
            foreach ($files as $file) {
                if (is_file($file) && ($now - filemtime($file)) > $max_age) {
                    unlink($file);
                }
            }
        }
    }
    
    /**
     * Проверка истекших временных ссылок
     */
    private function check_expired_temporary_links() {
        global $wpdb;
        
        // Очищаем expired transients
        $wpdb->query(
            "DELETE FROM {$wpdb->options} 
             WHERE option_name LIKE '_transient_rm_pdf_token_%' 
             AND option_value LIKE '%\"expires\"%' 
             AND option_value REGEXP '\"expires\":([0-9]+)' 
             AND JSON_UNQUOTE(JSON_EXTRACT(option_value, '$.\"expires\"')) < UNIX_TIMESTAMP()"
        );
    }
    
    /**
     * Отправка ежедневного дайджеста
     */
    private function send_daily_digest() {
        // Получаем пользователей, которые хотят получать дайджест
        $users = get_users(array(
            'meta_key' => 'rm_receive_digest',
            'meta_value' => '1'
        ));
        
        foreach ($users as $user) {
            $this->send_user_digest($user);
        }
    }
    
    /**
     * Отправка дайджеста пользователю
     */
    private function send_user_digest($user) {
        $task_manager = new RM_Task_Manager();
        
        // Получаем задачи пользователя
        $pending_tasks = $task_manager->get_user_tasks($user->ID, array(
            'status' => array('pending', 'in_progress')
        ));
        
        $overdue_tasks = array_filter($pending_tasks, function($task) {
            return $task->due_date && strtotime($task->due_date) < time();
        });
        
        // Если нет активных задач, не отправляем дайджест
        if (empty($pending_tasks) {
            return;
        }
        
        $subject = sprintf(__('Your Daily Task Digest - %s', 'report-manager'), date_i18n(get_option('date_format')));
        
        ob_start();
        ?>
        <h2><?php _e('Daily Task Digest', 'report-manager'); ?></h2>
        
        <?php if (!empty($overdue_tasks)): ?>
        <h3 style="color: #d63638;"><?php _e('Overdue Tasks', 'report-manager'); ?></h3>
        <ul>
            <?php foreach ($overdue_tasks as $task): ?>
            <li>
                <strong><?php echo esc_html($task->title); ?></strong>
                - <?php echo date_i18n(get_option('date_format'), strtotime($task->due_date)); ?>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>
        
        <h3><?php _e('Pending Tasks', 'report-manager'); ?></h3>
        <ul>
            <?php foreach ($pending_tasks as $task): ?>
            <li>
                <strong><?php echo esc_html($task->title); ?></strong>
                <?php if ($task->due_date): ?>
                - <?php echo date_i18n(get_option('date_format'), strtotime($task->due_date)); ?>
                <?php endif; ?>
            </li>
            <?php endforeach; ?>
        </ul>
        
        <p>
            <a href="<?php echo home_url('/reports/dashboard/'); ?>">
                <?php _e('View your dashboard', 'report-manager'); ?>
            </a>
        </p>
        <?php
        $message = ob_get_clean();
        
        $email_handler = new RM_Email_Handler();
        $email_handler->send_email(array(
            'to' => $user->user_email,
            'subject' => $subject,
            'message' => $message
        ));
    }
    
    /**
     * Оптимизация таблиц базы данных
     */
    private function optimize_database_tables() {
        global $wpdb;
        
        $tables = array(
            $wpdb->prefix . 'rm_groups',
            $wpdb->prefix . 'rm_user_groups',
            $wpdb->prefix . 'rm_projects',
            $wpdb->prefix . 'rm_report_templates',
            $wpdb->prefix . 'rm_report_fields',
            $wpdb->prefix . 'rm_tasks',
            $wpdb->prefix . 'rm_task_comments',
            $wpdb->prefix . 'rm_task_activities'
        );
        
        foreach ($tables as $table) {
            $wpdb->query("OPTIMIZE TABLE $table");
        }
    }
    
    /**
     * Проверка является ли страница плагина
     */
    private function is_rm_page() {
        return get_query_var('rm_page') !== '' || 
               is_post_type_archive('rm_report') ||
               is_singular('rm_report');
    }
}