<?php

class RM_Task_Manager {
    
    public function __construct() {
        add_action('wp_ajax_rm_create_task', array($this, 'ajax_create_task'));
        add_action('wp_ajax_rm_update_task', array($this, 'ajax_update_task'));
        add_action('wp_ajax_rm_delete_task', array($this, 'ajax_delete_task'));
        add_action('wp_ajax_rm_change_task_status', array($this, 'ajax_change_task_status'));
        add_action('wp_ajax_rm_add_task_comment', array($this, 'ajax_add_task_comment'));
        
        add_action('rm_after_report_signed', array($this, 'handle_report_signed_tasks'), 10, 2);
    }
    
    /**
     * Создание новой задачи
     */
    public function create_task($task_data) {
        global $wpdb;
        
        $current_user_id = get_current_user_id();
        
        $data = array(
            'group_id' => intval($task_data['group_id']),
            'project_id' => isset($task_data['project_id']) ? intval($task_data['project_id']) : 0,
            'title' => sanitize_text_field($task_data['title']),
            'description' => wp_kses_post($task_data['description']),
            'status' => 'pending',
            'priority' => sanitize_text_field($task_data['priority'] ?? 'medium'),
            'assigned_to' => isset($task_data['assigned_to']) ? intval($task_data['assigned_to']) : null,
            'created_by' => $current_user_id,
            'due_date' => !empty($task_data['due_date']) ? sanitize_text_field($task_data['due_date']) : null,
            'created_at' => current_time('mysql')
        );
        
        $result = $wpdb->insert(
            $wpdb->prefix . 'rm_tasks',
            $data,
            array('%d', '%d', '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s')
        );
        
        if ($result) {
            $task_id = $wpdb->insert_id;
            
            // Создаем активность
            $this->add_task_activity($task_id, 'task_created', $current_user_id);
            
            // Отправляем уведомления
            $this->send_task_notifications($task_id, 'created');
            
            return $task_id;
        }
        
        return false;
    }
    
    /**
     * Обновление задачи
     */
    public function update_task($task_id, $task_data) {
        global $wpdb;
        
        $current_user_id = get_current_user_id();
        $old_task = $this->get_task($task_id);
        
        $update_data = array();
        $update_format = array();
        
        $fields = array(
            'title' => '%s',
            'description' => '%s',
            'priority' => '%s',
            'assigned_to' => '%d',
            'due_date' => '%s'
        );
        
        foreach ($fields as $field => $format) {
            if (isset($task_data[$field])) {
                $update_data[$field] = $field === 'description' ? 
                    wp_kses_post($task_data[$field]) : 
                    sanitize_text_field($task_data[$field]);
                $update_format[] = $format;
            }
        }
        
        if (!empty($update_data)) {
            $update_data['updated_at'] = current_time('mysql');
            $update_format[] = '%s';
            
            $result = $wpdb->update(
                $wpdb->prefix . 'rm_tasks',
                $update_data,
                array('id' => $task_id),
                $update_format,
                array('%d')
            );
            
            if ($result) {
                // Логируем изменения
                $this->log_task_changes($task_id, $old_task, $update_data, $current_user_id);
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Изменение статуса задачи
     */
    public function change_task_status($task_id, $new_status, $user_id = null) {
        global $wpdb;
        
        $user_id = $user_id ?: get_current_user_id();
        $old_task = $this->get_task($task_id);
        
        $valid_statuses = array('pending', 'in_progress', 'review', 'completed');
        if (!in_array($new_status, $valid_statuses)) {
            return false;
        }
        
        $update_data = array('status' => $new_status);
        
        if ($new_status === 'completed') {
            $update_data['completed_at'] = current_time('mysql');
        } else {
            $update_data['completed_at'] = null;
        }
        
        $result = $wpdb->update(
            $wpdb->prefix . 'rm_tasks',
            $update_data,
            array('id' => $task_id),
            array('%s', '%s'),
            array('%d')
        );
        
        if ($result) {
            // Добавляем активность
            $this->add_task_activity($task_id, 'status_changed', $user_id, array(
                'old_status' => $old_task->status,
                'new_status' => $new_status
            ));
            
            // Отправляем уведомления
            $this->send_task_notifications($task_id, 'status_changed');
            
            return true;
        }
        
        return false;
    }
    
    /**
     * Получение задач пользователя
     */
    public function get_user_tasks($user_id, $filters = array()) {
        global $wpdb;
        
        $where_conditions = array("1=1");
        $query_params = array();
        
        // Базовые условия
        $where_conditions[] = "ug.user_id = %d";
        $query_params[] = $user_id;
        
        // Фильтр по статусу
        if (!empty($filters['status'])) {
            if (is_array($filters['status'])) {
                $placeholders = implode(',', array_fill(0, count($filters['status']), '%s'));
                $where_conditions[] = "t.status IN ($placeholders)";
                $query_params = array_merge($query_params, $filters['status']);
            } else {
                $where_conditions[] = "t.status = %s";
                $query_params[] = $filters['status'];
            }
        }
        
        // Фильтр по приоритету
        if (!empty($filters['priority'])) {
            $where_conditions[] = "t.priority = %s";
            $query_params[] = $filters['priority'];
        }
        
        // Фильтр по проекту
        if (!empty($filters['project_id'])) {
            $where_conditions[] = "t.project_id = %d";
            $query_params[] = $filters['project_id'];
        }
        
        // Фильтр по группе
        if (!empty($filters['group_id'])) {
            $where_conditions[] = "t.group_id = %d";
            $query_params[] = $filters['group_id'];
        }
        
        // Фильтр по назначенному пользователю
        if (isset($filters['assigned_to'])) {
            if ($filters['assigned_to'] === 'me') {
                $where_conditions[] = "t.assigned_to = %d";
                $query_params[] = $user_id;
            } elseif ($filters['assigned_to'] === 'unassigned') {
                $where_conditions[] = "t.assigned_to IS NULL";
            } elseif (is_numeric($filters['assigned_to'])) {
                $where_conditions[] = "t.assigned_to = %d";
                $query_params[] = $filters['assigned_to'];
            }
        }
        
        // Поиск
        if (!empty($filters['search'])) {
            $where_conditions[] = "(t.title LIKE %s OR t.description LIKE %s)";
            $search_term = '%' . $wpdb->esc_like($filters['search']) . '%';
            $query_params[] = $search_term;
            $query_params[] = $search_term;
        }
        
        $where_sql = implode(' AND ', $where_conditions);
        
        $sql = "SELECT t.*, 
                       g.name as group_name,
                       p.name as project_name,
                       creator.display_name as created_by_name,
                       assignee.display_name as assigned_to_name,
                       (SELECT COUNT(*) FROM {$wpdb->prefix}rm_task_comments WHERE task_id = t.id) as comment_count
                FROM {$wpdb->prefix}rm_tasks t
                INNER JOIN {$wpdb->prefix}rm_user_groups ug ON t.group_id = ug.group_id
                INNER JOIN {$wpdb->prefix}rm_groups g ON t.group_id = g.id
                LEFT JOIN {$wpdb->prefix}rm_projects p ON t.project_id = p.id
                LEFT JOIN {$wpdb->users} creator ON t.created_by = creator.ID
                LEFT JOIN {$wpdb->users} assignee ON t.assigned_to = assignee.ID
                WHERE {$where_sql}
                ORDER BY 
                    CASE t.priority 
                        WHEN 'urgent' THEN 1 
                        WHEN 'high' THEN 2 
                        WHEN 'medium' THEN 3 
                        WHEN 'low' THEN 4 
                    END,
                    t.due_date ASC,
                    t.created_at DESC";
        
        return $wpdb->get_results($wpdb->prepare($sql, $query_params));
    }
    
    /**
     * Получение конкретной задачи
     */
    public function get_task($task_id) {
        global $wpdb;
        
        $sql = "SELECT t.*, 
                       g.name as group_name,
                       p.name as project_name,
                       creator.display_name as created_by_name,
                       assignee.display_name as assigned_to_name
                FROM {$wpdb->prefix}rm_tasks t
                INNER JOIN {$wpdb->prefix}rm_groups g ON t.group_id = g.id
                LEFT JOIN {$wpdb->prefix}rm_projects p ON t.project_id = p.id
                LEFT JOIN {$wpdb->users} creator ON t.created_by = creator.ID
                LEFT JOIN {$wpdb->users} assignee ON t.assigned_to = assignee.ID
                WHERE t.id = %d";
        
        return $wpdb->get_row($wpdb->prepare($sql, $task_id));
    }
    
    /**
     * Добавление комментария к задаче
     */
    public function add_task_comment($task_id, $comment, $user_id = null) {
        global $wpdb;
        
        $user_id = $user_id ?: get_current_user_id();
        
        $result = $wpdb->insert(
            $wpdb->prefix . 'rm_task_comments',
            array(
                'task_id' => $task_id,
                'user_id' => $user_id,
                'comment' => wp_kses_post($comment),
                'created_at' => current_time('mysql')
            ),
            array('%d', '%d', '%s', '%s')
        );
        
        if ($result) {
            // Добавляем активность
            $this->add_task_activity($task_id, 'comment_added', $user_id);
            
            // Отправляем уведомления
            $this->send_task_notifications($task_id, 'comment_added', array(
                'comment' => $comment
            ));
            
            return $wpdb->insert_id;
        }
        
        return false;
    }
    
    /**
     * Получение комментариев задачи
     */
    public function get_task_comments($task_id) {
        global $wpdb;
        
        $sql = "SELECT c.*, u.display_name, u.user_email
                FROM {$wpdb->prefix}rm_task_comments c
                INNER JOIN {$wpdb->users} u ON c.user_id = u.ID
                WHERE c.task_id = %d
                ORDER BY c.created_at ASC";
        
        return $wpdb->get_results($wpdb->prepare($sql, $task_id));
    }
    
    /**
     * Добавление активности задачи
     */
    private function add_task_activity($task_id, $action, $user_id, $meta = array()) {
        global $wpdb;
        
        $wpdb->insert(
            $wpdb->prefix . 'rm_task_activities',
            array(
                'task_id' => $task_id,
                'user_id' => $user_id,
                'action' => $action,
                'meta' => serialize($meta),
                'created_at' => current_time('mysql')
            ),
            array('%d', '%d', '%s', '%s', '%s')
        );
    }
    
    /**
     * Получение активности задачи
     */
    public function get_task_activities($task_id) {
        global $wpdb;
        
        $sql = "SELECT a.*, u.display_name
                FROM {$wpdb->prefix}rm_task_activities a
                INNER JOIN {$wpdb->users} u ON a.user_id = u.ID
                WHERE a.task_id = %d
                ORDER BY a.created_at DESC";
        
        $activities = $wpdb->get_results($wpdb->prepare($sql, $task_id));
        
        foreach ($activities as $activity) {
            if ($activity->meta) {
                $activity->meta = unserialize($activity->meta);
            }
        }
        
        return $activities;
    }
    
    /**
     * Логирование изменений задачи
     */
    private function log_task_changes($task_id, $old_task, $new_data, $user_id) {
        $changes = array();
        
        foreach ($new_data as $field => $new_value) {
            $old_value = $old_task->$field ?? '';
            
            if ($old_value != $new_value) {
                $changes[$field] = array(
                    'from' => $old_value,
                    'to' => $new_value
                );
            }
        }
        
        if (!empty($changes)) {
            $this->add_task_activity($task_id, 'task_updated', $user_id, array(
                'changes' => $changes
            ));
        }
    }
    
    /**
     * Отправка уведомлений
     */
    private function send_task_notifications($task_id, $action, $extra_data = array()) {
        $notifications = new RM_Task_Notifications();
        $notifications->send_task_notification($task_id, $action, $extra_data);
    }
    
    /**
     * Обработка подписанных отчетов для создания задач
     */
    public function handle_report_signed_tasks($report_id, $report_data) {
        // Здесь можно автоматически создавать задачи на основе подписанных отчетов
        // Например, задачи на проверку, утверждение и т.д.
    }
    
    /**
     * AJAX: Создание задачи
     */
    public function ajax_create_task() {
        check_ajax_referer('rm_task_actions', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(__('Authentication required', 'report-manager'));
        }
        
        $task_data = array(
            'group_id' => intval($_POST['group_id']),
            'project_id' => isset($_POST['project_id']) ? intval($_POST['project_id']) : 0,
            'title' => sanitize_text_field($_POST['title']),
            'description' => wp_kses_post($_POST['description']),
            'priority' => sanitize_text_field($_POST['priority']),
            'assigned_to' => isset($_POST['assigned_to']) ? intval($_POST['assigned_to']) : null,
            'due_date' => sanitize_text_field($_POST['due_date'])
        );
        
        $task_id = $this->create_task($task_data);
        
        if ($task_id) {
            wp_send_json_success(array(
                'message' => __('Task created successfully', 'report-manager'),
                'task_id' => $task_id
            ));
        } else {
            wp_send_json_error(__('Failed to create task', 'report-manager'));
        }
    }
    
    /**
     * AJAX: Изменение статуса задачи
     */
    public function ajax_change_task_status() {
        check_ajax_referer('rm_task_actions', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(__('Authentication required', 'report-manager'));
        }
        
        $task_id = intval($_POST['task_id']);
        $new_status = sanitize_text_field($_POST['status']);
        
        // Проверяем права доступа
        if (!$this->user_can_modify_task(get_current_user_id(), $task_id)) {
            wp_send_json_error(__('Permission denied', 'report-manager'));
        }
        
        $result = $this->change_task_status($task_id, $new_status);
        
        if ($result) {
            wp_send_json_success(__('Task status updated', 'report-manager'));
        } else {
            wp_send_json_error(__('Failed to update task status', 'report-manager'));
        }
    }
    
    /**
     * Проверка прав на модификацию задачи
     */
    private function user_can_modify_task($user_id, $task_id) {
        $task = $this->get_task($task_id);
        
        if (!$task) {
            return false;
        }
        
        // Создатель задачи может ее изменять
        if ($task->created_by == $user_id) {
            return true;
        }
        
        // Назначенный пользователь может менять статус
        if ($task->assigned_to == $user_id) {
            return true;
        }
        
        // Суперпользователь группы может изменять задачи группы
        $groups = new RM_Groups();
        if ($groups->is_group_super_user($user_id, $task->group_id)) {
            return true;
        }
        
        return false;
    }
}