<?php

class RM_Admin_Templates {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_templates_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_template_scripts'));
    }
    
    public function add_templates_menu() {
        add_submenu_page(
            'report-manager',
            __('Templates', 'report-manager'),
            __('Templates', 'report-manager'),
            'rm_manage_templates',
            'rm-templates',
            array($this, 'render_templates_page')
        );
    }
    
    public function render_templates_page() {
        $templates = new RM_Templates();
        $available_templates = $templates->get_available_templates(get_current_user_id());
        
        include RM_PLUGIN_PATH . 'templates/admin/template-list.php';
    }
    
    public function enqueue_template_scripts($hook) {
        if ($hook !== 'report-manager_page_rm-templates') return;
        
        wp_enqueue_script(
            'rm-template-script',
            RM_PLUGIN_URL . 'assets/js/templates.js',
            array('jquery', 'jquery-ui-sortable'),
            RM_PLUGIN_VERSION,
            true
        );
        
        wp_enqueue_style(
            'rm-template-style',
            RM_PLUGIN_URL . 'assets/css/templates.css',
            array(),
            RM_PLUGIN_VERSION
        );
        
        wp_localize_script('rm-template-script', 'rm_template', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('rm_manage_templates'),
            'field_types' => $this->get_field_types_data()
        ));
    }
    
    private function get_field_types_data() {
        $field_types = new RM_Field_Types();
        return $field_types->get_available_types();
    }
}