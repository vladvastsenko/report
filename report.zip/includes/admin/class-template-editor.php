<?php

class RM_Template_Editor {
    
    public function render_editor($template_id = null) {
        $templates = new RM_Templates();
        $field_types = new RM_Field_Types();
        
        $template = null;
        $fields = array();
        
        if ($template_id) {
            $template = $templates->get_template($template_id);
            $fields = $templates->get_template_fields($template_id);
        }
        
        include RM_PLUGIN_PATH . 'templates/admin/template-editor.php';
    }
    
    public function handle_save_template() {
        if (!wp_verify_nonce($_POST['_wpnonce'], 'rm_save_template')) {
            wp_die(__('Security check failed', 'report-manager'));
        }
        
        $templates = new RM_Templates();
        
        $template_data = array(
            'name' => sanitize_text_field($_POST['template_name']),
            'description' => sanitize_textarea_field($_POST['template_description']),
            'group_id' => intval($_POST['template_group'])
        );
        
        if (!empty($_POST['template_id'])) {
            // Обновление существующего шаблона
            $result = $templates->update_template(intval($_POST['template_id']), $template_data);
        } else {
            // Создание нового шаблона
            $result = $templates->create_template($template_data);
        }
        
        if ($result) {
            wp_redirect(admin_url('admin.php?page=rm-templates&message=saved'));
            exit;
        } else {
            wp_redirect(admin_url('admin.php?page=rm-templates&message=error'));
            exit;
        }
    }
}