<?php

class RM_PDF_Fallback {
    
    private $dompdf_loaded = false;
    
    public function __construct() {
        $this->load_dompdf();
    }
    
    /**
     * Загрузка DomPDF
     */
    private function load_dompdf() {
        if ($this->dompdf_loaded) {
            return true;
        }
        
        // Проверяем несколько возможных путей к DomPDF
        $possible_paths = array(
            RM_PLUGIN_PATH . 'lib/dompdf/autoload.inc.php',
            WP_CONTENT_DIR . '/plugins/dompdf/autoload.inc.php',
            WP_CONTENT_DIR . '/libraries/dompdf/autoload.inc.php'
        );
        
        foreach ($possible_paths as $path) {
            if (file_exists($path)) {
                require_once $path;
                $this->dompdf_loaded = true;
                break;
            }
        }
        
        // Если DomPDF не найден, попытаемся скачать его
        if (!$this->dompdf_loaded) {
            $this->dompdf_loaded = $this->download_dompdf();
        }
        
        return $this->dompdf_loaded;
    }
    
    /**
     * Скачивание DomPDF если не установлен
     */
    private function download_dompdf() {
        $dompdf_path = RM_PLUGIN_PATH . 'lib/dompdf/';
        
        // Если папка уже существует
        if (file_exists($dompdf_path . 'autoload.inc.php')) {
            require_once $dompdf_path . 'autoload.inc.php';
            return true;
        }
        
        // Создаем папку если нужно
        if (!wp_mkdir_p($dompdf_path)) {
            error_log('Report Manager: Cannot create DomPDF directory');
            return false;
        }
        
        // Пытаемся скачать DomPDF
        $dompdf_zip_url = 'https://github.com/dompdf/dompdf/releases/download/v2.0.3/dompdf_2.0.3.zip';
        $zip_path = $dompdf_path . 'dompdf.zip';
        
        $response = wp_remote_get($dompdf_zip_url, array(
            'timeout' => 30,
            'stream' => true,
            'filename' => $zip_path
        ));
        
        if (is_wp_error($response) || !file_exists($zip_path)) {
            error_log('Report Manager: Failed to download DomPDF');
            return false;
        }
        
        // Распаковываем ZIP
        if (!class_exists('ZipArchive')) {
            error_log('Report Manager: ZipArchive not available');
            return false;
        }
        
        $zip = new ZipArchive();
        if ($zip->open($zip_path) === TRUE) {
            $zip->extractTo($dompdf_path);
            $zip->close();
            
            // Удаляем ZIP файл
            unlink($zip_path);
            
            // Проверяем что распаковалось правильно
            if (file_exists($dompdf_path . 'autoload.inc.php')) {
                require_once $dompdf_path . 'autoload.inc.php';
                return true;
            }
        }
        
        error_log('Report Manager: Failed to extract DomPDF');
        return false;
    }
    
    /**
     * Генерация PDF через DomPDF
     */
    public function generate_pdf($html_content, $options = array()) {
        if (!$this->dompdf_loaded) {
            error_log('Report Manager: DomPDF not loaded');
            return false;
        }
        
        try {
            // Настройки по умолчанию
            $default_options = array(
                'paper_size' => 'A4',
                'orientation' => 'portrait',
                'font_family' => 'Arial',
                'font_size' => '12pt'
            );
            
            $options = wp_parse_args($options, $default_options);
            
            // Создаем объект DomPDF
            $dompdf = new Dompdf\Dompdf();
            
            // Настройки
            $dompdf_options = new Dompdf\Options();
            $dompdf_options->set('isRemoteEnabled', true);
            $dompdf_options->set('isHtml5ParserEnabled', true);
            $dompdf_options->set('chroot', WP_CONTENT_DIR);
            $dompdf_options->set('tempDir', WP_CONTENT_DIR . '/uploads/');
            $dompdf_options->set('fontDir', WP_CONTENT_DIR . '/uploads/rm_fonts/');
            $dompdf_options->set('fontCache', WP_CONTENT_DIR . '/uploads/rm_fonts/');
            
            $dompdf->setOptions($dompdf_options);
            $dompdf->setPaper($options['paper_size'], $options['orientation']);
            
            // Загружаем HTML
            $dompdf->loadHtml($html_content);
            $dompdf->render();
            
            // Сохраняем файл
            $upload_dir = wp_upload_dir();
            $filename = 'report_' . current_time('Y-m-d_H-i-s') . '.pdf';
            $filepath = $upload_dir['path'] . '/' . $filename;
            
            file_put_contents($filepath, $dompdf->output());
            
            return array(
                'success' => true,
                'filepath' => $filepath,
                'filename' => $filename,
                'url' => $upload_dir['url'] . '/' . $filename,
                'engine' => 'DomPDF (Fallback)'
            );
            
        } catch (Exception $e) {
            error_log('Report Manager - DomPDF Error: ' . $e->getMessage());
            return false;
        }
    }
}