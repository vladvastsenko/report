<?php

class RM_Post_Types {
    
    public function register_post_types() {
        // Тип записи: Отчеты
        $report_labels = array(
            'name' => __('Reports', 'report-manager'),
            'singular_name' => __('Report', 'report-manager'),
            'menu_name' => __('Reports', 'report-manager'),
            'name_admin_bar' => __('Report', 'report-manager'),
            'add_new' => __('Add New', 'report-manager'),
            'add_new_item' => __('Add New Report', 'report-manager'),
            'new_item' => __('New Report', 'report-manager'),
            'edit_item' => __('Edit Report', 'report-manager'),
            'view_item' => __('View Report', 'report-manager'),
            'all_items' => __('All Reports', 'report-manager'),
            'search_items' => __('Search Reports', 'report-manager'),
            'not_found' => __('No reports found.', 'report-manager'),
            'not_found_in_trash' => __('No reports found in Trash.', 'report-manager')
        );
        
        $report_args = array(
            'labels' => $report_labels,
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'query_var' => true,
            'rewrite' => array('slug' => 'reports'),
            'capability_type' => 'post',
            'has_archive' => true,
            'hierarchical' => false,
            'menu_position' => 25,
            'menu_icon' => 'dashicons-clipboard',
            'supports' => array('title', 'author'),
            'show_in_rest' => false, // Отключаем Gutenberg
            'capabilities' => array(
                'create_posts' => 'rm_create_reports',
            ),
            'map_meta_cap' => true,
        );
        
        register_post_type('rm_report', $report_args);
        
        // Тип записи: Проекты (для иерархии)
        $project_labels = array(
            'name' => __('Projects', 'report-manager'),
            'singular_name' => __('Project', 'report-manager'),
            'menu_name' => __('Projects', 'report-manager'),
            'name_admin_bar' => __('Project', 'report-manager'),
            'add_new' => __('Add New', 'report-manager'),
            'add_new_item' => __('Add New Project', 'report-manager'),
            'new_item' => __('New Project', 'report-manager'),
            'edit_item' => __('Edit Project', 'report-manager'),
            'view_item' => __('View Project', 'report-manager'),
            'all_items' => __('All Projects', 'report-manager'),
            'search_items' => __('Search Projects', 'report-manager'),
        );
        
        $project_args = array(
            'labels' => $project_labels,
            'public' => false,
            'publicly_queryable' => false,
            'show_ui' => true,
            'show_in_menu' => 'edit.php?post_type=rm_report',
            'query_var' => true,
            'rewrite' => false,
            'capability_type' => 'post',
            'has_archive' => false,
            'hierarchical' => true, // Включаем иерархию для parent-child отношений
            'supports' => array('title', 'page-attributes'),
            'show_in_rest' => false,
            'capabilities' => array(
                'create_posts' => 'rm_manage_projects',
            ),
            'map_meta_cap' => true,
        );
        
        register_post_type('rm_project', $project_args);
    }
    
    public function register_taxonomies() {
        // Таксономия для группировки отчетов (если понадобится)
        // Пока оставляем пустым для будущего расширения
    }
}