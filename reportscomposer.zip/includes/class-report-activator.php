<?php

class RM_Report_Activator {
    
    public static function activate() {
        self::check_dependencies();
        self::setup_database();
        self::setup_roles();
        self::setup_post_types();
        self::flush_rewrite_rules();
        self::schedule_events();
        
        error_log('Report Manager: Plugin activated successfully');
    }
    
    public static function deactivate() {
        self::clear_scheduled_events();
        self::flush_rewrite_rules();
        
        error_log('Report Manager: Plugin deactivated');
    }
    
    public static function uninstall() {
        if (!defined('WP_UNINSTALL_PLUGIN')) {
            exit;
        }
        
        // Опционально: удаление данных
        // self::delete_plugin_data();
        
        error_log('Report Manager: Plugin uninstalled');
    }
    
    /**
     * Проверка зависимостей
     */
    private static function check_dependencies() {
        $errors = array();
        
        // Проверка PHP версии
        if (version_compare(PHP_VERSION, '7.4', '<')) {
            $errors[] = 'PHP 7.4 or higher is required';
        }
        
        // Проверка WordPress версии
        if (version_compare(get_bloginfo('version'), '5.8', '<')) {
            $errors[] = 'WordPress 5.8 or higher is required';
        }
        
        // Проверка обязательных плагинов
        if (!is_plugin_active('paid-memberships-pro/paid-memberships-pro.php')) {
            $errors[] = 'Paid Memberships Pro plugin is required';
        }
        
        if (!empty($errors)) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                '<h1>Report Manager - Dependencies Missing</h1>' .
                '<p>The following requirements are missing:</p>' .
                '<ul><li>' . implode('</li><li>', $errors) . '</li></ul>' .
                '<p><a href="' . admin_url('plugins.php') . '">Return to plugins page</a></p>'
            );
        }
    }
    
    /**
     * Настройка базы данных
     */
    private static function setup_database() {
        $database = new RM_Database();
        $database->create_tables();
    }
    
    /**
     * Настройка ролей и прав
     */
    private static function setup_roles() {
        $roles = new RM_Roles();
        $roles->setup_roles();
    }
    
    /**
     * Регистрация типов записей
     */
    private static function setup_post_types() {
        $post_types = new RM_Post_Types();
        $post_types->register_post_types();
        $post_types->register_taxonomies();
    }
    
    /**
     * Сброс правил перезаписи URL
     */
    private static function flush_rewrite_rules() {
        flush_rewrite_rules();
    }
    
    /**
     * Настройка cron событий
     */
    private static function schedule_events() {
        if (!wp_next_scheduled('rm_daily_maintenance')) {
            wp_schedule_event(time(), 'daily', 'rm_daily_maintenance');
        }
        
        if (!wp_next_scheduled('rm_cleanup_temp_files')) {
            wp_schedule_event(time(), 'twicedaily', 'rm_cleanup_temp_files');
        }
    }
    
    /**
     * Очистка cron событий
     */
    private static function clear_scheduled_events() {
        wp_clear_scheduled_hook('rm_daily_maintenance');
        wp_clear_scheduled_hook('rm_cleanup_temp_files');
    }
    
    /**
     * Удаление данных плагина (опционально)
     */
    private static function delete_plugin_data() {
        global $wpdb;
        
        // Таблицы для удаления
        $tables = array(
            $wpdb->prefix . 'rm_groups',
            $wpdb->prefix . 'rm_user_groups',
            $wpdb->prefix . 'rm_projects',
            $wpdb->prefix . 'rm_report_templates',
            $wpdb->prefix . 'rm_report_fields',
            $wpdb->prefix . 'rm_tasks',
            $wpdb->prefix . 'rm_task_comments',
            $wpdb->prefix . 'rm_task_activities',
            $wpdb->prefix . 'rm_invitations'
        );
        
        // Удаляем таблицы
        foreach ($tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS $table");
        }
        
        // Удаляем опции
        $options = array(
            'rm_preferred_pdf_plugin',
            'rm_pdf_default_settings',
            'rm_db_version'
        );
        
        foreach ($options as $option) {
            delete_option($option);
        }
        
        // Удаляем transients
        $wpdb->query(
            "DELETE FROM {$wpdb->options} 
             WHERE option_name LIKE '_transient_rm_%' 
             OR option_name LIKE '_transient_timeout_rm_%'"
        );
    }
}