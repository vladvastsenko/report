<?php

class RM_Database {
    
    public function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Таблица групп
        $table_groups = $wpdb->prefix . 'rm_groups';
        $table_user_groups = $wpdb->prefix . 'rm_user_groups';
        $table_projects = $wpdb->prefix . 'rm_projects';
        $table_report_templates = $wpdb->prefix . 'rm_report_templates';
        $table_report_fields = $wpdb->prefix . 'rm_report_fields';
        $table_tasks = $wpdb->prefix . 'rm_tasks';
        
        $sql = array();
        
        // Группы
        $sql[] = "CREATE TABLE {$table_groups} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            description text,
            super_user_id bigint(20) NOT NULL,
            allow_custom_pdf tinyint(1) DEFAULT 1,
            logo_url varchar(500),
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY super_user_id (super_user_id)
        ) {$charset_collate};";
        
        // Связь пользователей с группами
        $sql[] = "CREATE TABLE {$table_user_groups} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            group_id bigint(20) NOT NULL,
            role varchar(50) DEFAULT 'user',
            invited_by bigint(20),
            invited_at datetime,
            joined_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY user_group (user_id, group_id),
            KEY group_id (group_id),
            KEY invited_by (invited_by)
        ) {$charset_collate};";
        
        // Проекты с иерархией
        $sql[] = "CREATE TABLE {$table_projects} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            group_id bigint(20) NOT NULL,
            parent_id bigint(20) DEFAULT 0,
            name varchar(255) NOT NULL,
            address text,
            hierarchy_level tinyint(2) DEFAULT 1,
            sort_order int(11) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY group_id (group_id),
            KEY parent_id (parent_id),
            KEY hierarchy_level (hierarchy_level)
        ) {$charset_collate};";
        
        // Шаблоны отчетов
        $sql[] = "CREATE TABLE {$table_report_templates} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            description text,
            group_id bigint(20) DEFAULT 0, // 0 = глобальный шаблон админа
            created_by bigint(20) NOT NULL,
            is_active tinyint(1) DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY group_id (group_id),
            KEY created_by (created_by)
        ) {$charset_collate};";
        
        // Поля шаблонов отчетов
        $sql[] = "CREATE TABLE {$table_report_fields} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            template_id bigint(20) NOT NULL,
            field_type varchar(50) NOT NULL, // text, textarea, select, number, date, file, location
            field_name varchar(255) NOT NULL,
            field_label varchar(255) NOT NULL,
            field_options text, // для select и multiple choice
            is_required tinyint(1) DEFAULT 0,
            sort_order int(11) DEFAULT 0,
            settings text, // дополнительные настройки поля
            PRIMARY KEY (id),
            KEY template_id (template_id),
            KEY sort_order (sort_order)
        ) {$charset_collate};";
        
        // Задачи
        $sql[] = "CREATE TABLE {$table_tasks} (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            group_id bigint(20) NOT NULL,
            project_id bigint(20) DEFAULT 0,
            title varchar(500) NOT NULL,
            description text,
            status varchar(50) DEFAULT 'pending', // pending, in_progress, review, completed
            priority varchar(50) DEFAULT 'medium', // low, medium, high, urgent
            assigned_to bigint(20),
            created_by bigint(20) NOT NULL,
            due_date date,
            completed_at datetime,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY group_id (group_id),
            KEY project_id (project_id),
            KEY assigned_to (assigned_to),
            KEY status (status),
            KEY due_date (due_date)
        ) {$charset_collate};";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

// Таблица приглашений
$table_invitations = $wpdb->prefix . 'rm_invitations';

$sql[] = "CREATE TABLE {$table_invitations} (
    id bigint(20) NOT NULL AUTO_INCREMENT,
    email varchar(255) NOT NULL,
    group_id bigint(20) NOT NULL,
    invited_by bigint(20) NOT NULL,
    token varchar(32) NOT NULL,
    status varchar(20) DEFAULT 'pending',
    created_at datetime DEFAULT CURRENT_TIMESTAMP,
    expires_at datetime NOT NULL,
    accepted_at datetime,
    PRIMARY KEY (id),
    UNIQUE KEY token (token),
    KEY email (email),
    KEY group_id (group_id),
    KEY status (status),
    KEY expires_at (expires_at)
) {$charset_collate};";
        
        // Логируем ошибки если есть
        if (!empty($wpdb->last_error)) {
            error_log('Report Manager DB Error: ' . $wpdb->last_error);
        }
    }
}