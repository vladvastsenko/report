<?php

class RM_Report_Builder {
    
    public function __construct() {
        add_action('wp_ajax_rm_save_report', array($this, 'ajax_save_report'));
        add_action('wp_ajax_rm_load_template', array($this, 'ajax_load_template'));
        add_action('wp_ajax_rm_delete_report', array($this, 'ajax_delete_report'));
        add_action('wp_ajax_rm_sign_report', array($this, 'ajax_sign_report'));
    }
    
    /**
     * Создание нового отчета
     */
    public function create_report($data) {
        $current_user = wp_get_current_user();
        
        $post_data = array(
            'post_title' => sanitize_text_field($data['title']),
            'post_type' => 'rm_report',
            'post_status' => 'draft',
            'post_author' => $current_user->ID,
            'post_content' => ''
        );
        
        $report_id = wp_insert_post($post_data);
        
        if ($report_id && !is_wp_error($report_id)) {
            // Сохраняем метаданные
            $this->save_report_metadata($report_id, $data);
            
            // Сохраняем данные полей
            $this->save_report_fields($report_id, $data);
            
            return $report_id;
        }
        
        return false;
    }
    
    /**
     * Сохранение метаданных отчета
     */
    private function save_report_metadata($report_id, $data) {
        // Группа
        if (isset($data['group_id'])) {
            update_post_meta($report_id, '_rm_report_group', intval($data['group_id']));
        }
        
        // Проект
        if (isset($data['project_id'])) {
            update_post_meta($report_id, '_rm_report_project', intval($data['project_id']));
        }
        
        // Шаблон
        if (isset($data['template_id'])) {
            update_post_meta($report_id, '_rm_report_template', intval($data['template_id']));
        }
        
        // Адрес
        if (isset($data['address'])) {
            update_post_meta($report_id, '_rm_report_address', sanitize_text_field($data['address']));
        }
        
        // Геопозиция
        if (isset($data['location'])) {
            update_post_meta($report_id, '_rm_report_location', $data['location']);
        }
        
        // Статус подписи
        update_post_meta($report_id, '_rm_report_signed', 0);
        update_post_meta($report_id, '_rm_report_signed_date', '');
        update_post_meta($report_id, '_rm_report_signed_by', '');
    }
    
    /**
     * Сохранение данных полей отчета
     */
    private function save_report_fields($report_id, $data) {
        $report_data = array();
        
        foreach ($data as $key => $value) {
            if (strpos($key, 'rm_field_') === 0) {
                $field_name = str_replace('rm_field_', '', $key);
                $report_data[$field_name] = $this->sanitize_field_value($value);
            }
        }
        
        // Обработка загруженных файлов
        $report_data = $this->handle_file_uploads($report_data, $report_id);
        
        update_post_meta($report_id, '_rm_report_data', $report_data);
    }
    
    /**
     * Санитизация значений полей
     */
    private function sanitize_field_value($value) {
        if (is_array($value)) {
            return array_map('sanitize_text_field', $value);
        }
        
        return sanitize_text_field($value);
    }
    
    /**
     * Обработка загрузки файлов
     */
    private function handle_file_uploads($report_data, $report_id) {
        if (!empty($_FILES)) {
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/media.php');
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            
            foreach ($_FILES as $field_name => $file) {
                if ($file['error'] === UPLOAD_ERR_OK) {
                    $field_key = str_replace('rm_field_', '', $field_name);
                    
                    // Загружаем файл
                    $upload = wp_handle_upload($file, array('test_form' => false));
                    
                    if (!isset($upload['error'])) {
                        $report_data[$field_key] = $upload['url'];
                        
                        // Создаем attachment
                        $attachment = array(
                            'post_mime_type' => $upload['type'],
                            'post_title' => preg_replace('/\.[^.]+$/', '', basename($upload['file'])),
                            'post_content' => '',
                            'post_status' => 'inherit',
                            'guid' => $upload['url']
                        );
                        
                        $attach_id = wp_insert_attachment($attachment, $upload['file'], $report_id);
                        
                        // Генерируем метаданные
                        $attach_data = wp_generate_attachment_metadata($attach_id, $upload['file']);
                        wp_update_attachment_metadata($attach_id, $attach_data);
                    }
                }
            }
        }
        
        return $report_data;
    }
    
    /**
     * Подписание отчета
     */
    public function sign_report($report_id) {
        $current_user = wp_get_current_user();
        
        update_post_meta($report_id, '_rm_report_signed', 1);
        update_post_meta($report_id, '_rm_report_signed_date', current_time('mysql'));
        update_post_meta($report_id, '_rm_report_signed_by', $current_user->ID);
        
        // Меняем статус на опубликованный (теперь виден всем в группе)
        wp_update_post(array(
            'ID' => $report_id,
            'post_status' => 'publish'
        ));
        
        return true;
    }
    
    /**
     * AJAX: Сохранение отчета
     */
    public function ajax_save_report() {
        check_ajax_referer('rm_frontend_actions', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(__('Authentication required', 'report-manager'));
        }
        
        $data = $_POST;
        $report_id = isset($data['report_id']) ? intval($data['report_id']) : 0;
        
        if ($report_id) {
            // Обновление существующего отчета
            $result = $this->update_report($report_id, $data);
        } else {
            // Создание нового отчета
            $result = $this->create_report($data);
        }
        
        if ($result) {
            wp_send_json_success(array(
                'message' => __('Report saved successfully', 'report-manager'),
                'report_id' => $result,
                'redirect_url' => $this->get_report_url($result)
            ));
        } else {
            wp_send_json_error(__('Failed to save report', 'report-manager'));
        }
    }
    
    /**
     * AJAX: Загрузка шаблона
     */
    public function ajax_load_template() {
        check_ajax_referer('rm_frontend_actions', 'nonce');
        
        $template_id = intval($_POST['template_id']);
        $templates = new RM_Templates();
        $field_types = new RM_Field_Types();
        
        $fields = $templates->get_template_fields($template_id);
        
        $html = '';
        foreach ($fields as $field) {
            $html .= $field_types->render_field_frontend($field);
        }
        
        wp_send_json_success(array(
            'html' => $html,
            'fields_count' => count($fields)
        ));
    }
    
    /**
     * AJAX: Подписание отчета
     */
    public function ajax_sign_report() {
        check_ajax_referer('rm_frontend_actions', 'nonce');
        
        $report_id = intval($_POST['report_id']);
        
        // Проверяем что пользователь является автором отчета
        $report = get_post($report_id);
        if ($report->post_author != get_current_user_id()) {
            wp_send_json_error(__('You can only sign your own reports', 'report-manager'));
        }
        
        $result = $this->sign_report($report_id);
        
        if ($result) {
            wp_send_json_success(__('Report signed successfully', 'report-manager'));
        } else {
            wp_send_json_error(__('Failed to sign report', 'report-manager'));
        }
    }
    
    /**
     * Получение URL отчета
     */
    private function get_report_url($report_id) {
        return home_url("/reports/{$report_id}/");
    }
}