<?php

class RM_Admin_Menu {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menus'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
    }
    
    public function add_admin_menus() {
        // Главное меню модуля
        add_menu_page(
            __('Report Manager', 'report-manager'),
            __('Report Manager', 'report-manager'),
            'read', // Базовое право - просмотр
            'report-manager',
            array($this, 'render_dashboard'),
            'dashicons-clipboard',
            30
        );
        
        // Дашборд
        add_submenu_page(
            'report-manager',
            __('Dashboard', 'report-manager'),
            __('Dashboard', 'report-manager'),
            'read',
            'report-manager',
            array($this, 'render_dashboard')
        );
        
        // Группы (только для суперпользователей и админов)
        add_submenu_page(
            'report-manager',
            __('Groups', 'report-manager'),
            __('Groups', 'report-manager'),
            'rm_manage_group',
            'rm-groups',
            array($this, 'render_groups_page')
        );
        
        // Отчеты
        add_submenu_page(
            'report-manager',
            __('Reports', 'report-manager'),
            __('Reports', 'report-manager'),
            'rm_create_reports',
            'edit.php?post_type=rm_report'
        );
        
        // Проекты
        add_submenu_page(
            'report-manager',
            __('Projects', 'report-manager'),
            __('Projects', 'report-manager'),
            'rm_manage_projects',
            'edit.php?post_type=rm_project'
        );
        
        // Настройки PDF (для суперпользователей)
        add_submenu_page(
            'report-manager',
            __('PDF Settings', 'report-manager'),
            __('PDF Settings', 'report-manager'),
            'rm_manage_pdf_settings',
            'rm-pdf-settings',
            array($this, 'render_pdf_settings')
        );
    }
    
    public function render_dashboard() {
        $current_user = wp_get_current_user();
        $user_groups = $this->get_user_groups_data($current_user->ID);
        
        include RM_PLUGIN_PATH . 'templates/admin/dashboard.php';
    }
    
    public function render_groups_page() {
        $groups_handler = new RM_Admin_Groups();
        $groups_handler->render_page();
    }
    
    public function render_pdf_settings() {
        include RM_PLUGIN_PATH . 'templates/admin/pdf-settings.php';
    }
    
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'report-manager') === false) return;
        
        wp_enqueue_style(
            'rm-admin-style',
            RM_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            RM_PLUGIN_VERSION
        );
        
        wp_enqueue_script(
            'rm-admin-script',
            RM_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            RM_PLUGIN_VERSION,
            true
        );
        
        wp_localize_script('rm-admin-script', 'rm_ajax', array(
            'url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('rm_manage_groups')
        ));
    }
    
    private function get_user_groups_data($user_id) {
        $groups = new RM_Groups();
        return $groups->get_user_groups($user_id);
    }
}