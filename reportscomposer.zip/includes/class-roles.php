<?php

class RM_Roles {
    
    public function setup_roles() {
        // Суперпользователь (расширенные права в рамках своей группы)
        add_role('rm_super_user', __('Super User', 'report-manager'), array(
            'read' => true,
            'upload_files' => true,
        ));
        
        // Пользователь группы (базовые права)
        add_role('rm_group_user', __('Group User', 'report-manager'), array(
            'read' => true,
            'upload_files' => true,
        ));
        
        // Добавляем capabilities к стандартным ролям
        $this->add_capabilities();
    }
    
    private function add_capabilities() {
        global $wp_roles;
        
        if (!isset($wp_roles)) {
            $wp_roles = new WP_Roles();
        }
        
        // Администратор получает полный контроль
        $admin_caps = $this->get_all_capabilities();
        foreach ($admin_caps as $cap) {
            $wp_roles->add_cap('administrator', $cap);
        }
        
        // Суперпользователь - права для управления группой
        $super_user_caps = array(
            'rm_manage_group',
            'rm_invite_users',
            'rm_manage_projects',
            'rm_manage_templates',
            'rm_manage_pdf_settings',
            'rm_view_group_reports',
            'rm_create_reports',
            'rm_manage_tasks'
        );
        
        foreach ($super_user_caps as $cap) {
            $wp_roles->add_cap('rm_super_user', $cap);
        }
        
        // Обычный пользователь группы
        $group_user_caps = array(
            'rm_create_reports',
            'rm_view_group_reports',
            'rm_manage_own_tasks'
        );
        
        foreach ($group_user_caps as $cap) {
            $wp_roles->add_cap('rm_group_user', $cap);
        }
    }
    
    private function get_all_capabilities() {
        return array(
            'rm_manage_groups',
            'rm_manage_all_reports',
            'rm_manage_global_templates',
            'rm_manage_system',
            'rm_manage_group',
            'rm_invite_users',
            'rm_manage_projects',
            'rm_manage_templates',
            'rm_manage_pdf_settings',
            'rm_view_group_reports',
            'rm_create_reports',
            'rm_manage_tasks',
            'rm_manage_own_tasks'
        );
    }
}