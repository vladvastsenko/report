<?php
/**
 * PDF Report Content Template
 */
?>
<main class="pdf-content">
    <?php if (!empty($report_data)): ?>
        <table class="report-data">
            <thead>
                <tr>
                    <th width="30%"><?php _e('Field', 'report-manager'); ?></th>
                    <th width="70%"><?php _e('Value', 'report-manager'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($report_data as $field_name => $field_value): ?>
                    <tr>
                        <td><strong><?php echo esc_html($this->format_field_name($field_name)); ?></strong></td>
                        <td>
                            <?php if (is_array($field_value)): ?>
                                <?php echo esc_html(implode(', ', $field_value)); ?>
                            <?php elseif (wp_http_validate_url($field_value) && preg_match('/\.(jpg|jpeg|png|gif)$/i', $field_value)): ?>
                                <img src="<?php echo esc_url($field_value); ?>" style="max-width: 200px; max-height: 150px;">
                            <?php else: ?>
                                <?php echo esc_html($field_value); ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p><?php _e('No report data available.', 'report-manager'); ?></p>
    <?php endif; ?>
    
    <?php if (get_post_meta($report->ID, '_rm_report_signed', true)): ?>
        <div class="signature-section">
            <h3><?php _e('Signature', 'report-manager'); ?></h3>
            <p>
                <strong><?php _e('Signed by:', 'report-manager'); ?></strong> 
                <?php echo get_the_author_meta('display_name', get_post_meta($report->ID, '_rm_report_signed_by', true)); ?>
            </p>
            <p>
                <strong><?php _e('Signed on:', 'report-manager'); ?></strong> 
                <?php echo date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime(get_post_meta($report->ID, '_rm_report_signed_date', true))); ?>
            </p>
        </div>
    <?php endif; ?>
</main>