<style>
    body {
        font-family: {{font_family}};
        font-size: {{font_size}};
        color: #333;
        line-height: 1.4;
    }
    
    .pdf-header {
        border-bottom: 2px solid {{primary_color}};
        padding-bottom: 10px;
        margin-bottom: 20px;
    }
    
    .pdf-header h1 {
        color: {{primary_color}};
        margin: 0 0 10px 0;
    }
    
    .report-meta p {
        margin: 2px 0;
        font-size: 0.9em;
    }
    
    table.report-data {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
    }
    
    table.report-data th {
        background-color: {{primary_color}};
        color: white;
        padding: 8px;
        text-align: left;
    }
    
    table.report-data td {
        padding: 8px;
        border: 1px solid #ddd;
        vertical-align: top;
    }
    
    .signature-section {
        margin-top: 30px;
        padding-top: 20px;
        border-top: 1px solid #ddd;
    }
    
    .page-number {
        text-align: center;
        font-size: 0.8em;
        color: #666;
        margin-top: 20px;
    }
</style>