<?php
/**
 * Template: Language Selector
 */
if (!defined('ABSPATH')) exit;

$i18n = new RM_I18n();
$current_language = $i18n->get_user_language();
$supported_languages = $i18n->get_supported_languages();
?>

<div class="rm-language-selector">
    <button type="button" class="rm-language-current">
        <?php 
        $current_lang_data = array_filter($supported_languages, function($lang) use ($current_language) {
            return $lang['wp_locale'] === $current_language;
        });
        $current_lang_data = reset($current_lang_data);
        ?>
        <?php if ($current_lang_data): ?>
            <span class="rm-language-flag"><?php echo $current_lang_data['flag']; ?></span>
            <span class="rm-language-name"><?php echo $current_lang_data['native_name']; ?></span>
        <?php else: ?>
            <span class="rm-language-flag">🌐</span>
            <span class="rm-language-name"><?php _e('Language', 'report-manager'); ?></span>
        <?php endif; ?>
        <span class="rm-language-arrow">▼</span>
    </button>
    
    <div class="rm-language-dropdown">
        <?php foreach ($supported_languages as $lang): ?>
            <button type="button" class="rm-language-option <?php echo $lang['wp_locale'] === $current_language ? 'rm-language-active' : ''; ?>" 
                    data-language="<?php echo $lang['wp_locale']; ?>">
                <span class="rm-language-flag"><?php echo $lang['flag']; ?></span>
                <span class="rm-language-name"><?php echo $lang['native_name']; ?></span>
            </button>
        <?php endforeach; ?>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    $('.rm-language-option').on('click', function() {
        const language = $(this).data('language');
        
        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',
            data: {
                action: 'rm_change_language',
                language: language,
                nonce: '<?php echo wp_create_nonce('rm_i18n'); ?>'
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert('Error changing language');
                }
            }
        });
    });
});
</script>