(function($) {
    'use strict';

    class LocationManager {
        constructor() {
            this.init();
        }

        init() {
            this.bindEvents();
        }

        bindEvents() {
            // Получение геолокации
            $(document).on('click', '.rm-get-location', (e) => this.getLocation(e));
            
            // Показ/скрытие карты
            $(document).on('click', '.rm-show-map', (e) => this.toggleMap(e));
        }

        getLocation(e) {
            const $button = $(e.target);
            const $container = $button.closest('.rm-location-field');
            
            if (!navigator.geolocation) {
                this.showError('Geolocation is not supported by this browser.');
                return;
            }

            $button.prop('disabled', true).text('Getting location...');

            navigator.geolocation.getCurrentPosition(
                (position) => this.handleSuccess(position, $container),
                (error) => this.handleError(error, $container),
                {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 60000
                }
            );
        }

        handleSuccess(position, $container) {
            const coords = position.coords;
            
            // Заполняем скрытые поля
            $container.find('input[name*="[lat]"]').val(coords.latitude);
            $container.find('input[name*="[lng]"]').val(coords.longitude);
            
            // Показываем точность
            this.showMessage(
                `Location found (accuracy: ${Math.round(coords.accuracy)} meters)`,
                'success',
                $container
            );

            // Активируем кнопку показа карты
            $container.find('.rm-show-map').prop('disabled', false);
            
            // Обновляем кнопку
            $container.find('.rm-get-location')
                .prop('disabled', false)
                .text('Update Location');
        }

        handleError(error, $container) {
            let message = 'Error getting location: ';
            
            switch(error.code) {
                case error.PERMISSION_DENIED:
                    message += 'Permission denied.';
                    break;
                case error.POSITION_UNAVAILABLE:
                    message += 'Position unavailable.';
                    break;
                case error.TIMEOUT:
                    message += 'Request timeout.';
                    break;
                default:
                    message += 'Unknown error.';
                    break;
            }

            this.showError(message, $container);
            $container.find('.rm-get-location')
                .prop('disabled', false)
                .text('Get Location');
        }

        toggleMap(e) {
            const $button = $(e.target);
            const $container = $button.closest('.rm-location-field');
            const $map = $container.find('.rm-location-map');
            
            if ($map.is(':visible')) {
                $map.hide();
                $button.text('Show Map');
            } else {
                const lat = $container.find('input[name*="[lat]"]').val();
                const lng = $container.find('input[name*="[lng]"]').val();
                
                if (lat && lng) {
                    this.showMap($map, parseFloat(lat), parseFloat(lng));
                    $map.show();
                    $button.text('Hide Map');
                } else {
                    this.showError('No location data available.', $container);
                }
            }
        }

        showMap($map, lat, lng) {
            // Простая реализация карты с использованием iframe Google Maps
            // В реальном приложении используйте Google Maps JavaScript API
            const mapUrl = `https://maps.google.com/maps?q=${lat},${lng}&z=15&output=embed`;
            $map.html(`<iframe width="100%" height="200" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="${mapUrl}"></iframe>`);
        }

        showMessage(message, type, $container) {
            const $message = $(`<div class="rm-location-message rm-message-${type}">${message}</div>`);
            $container.find('.rm-location-messages').html($message);
            
            setTimeout(() => {
                $message.fadeOut();
            }, 5000);
        }

        showError(message, $container) {
            this.showMessage(message, 'error', $container);
        }
    }

    $(document).ready(() => {
        new LocationManager();
    });

})(jQuery);