(function($) {
    'use strict';

    class GeolocationManager {
        constructor() {
            this.currentPosition = null;
            this.isSupported = 'geolocation' in navigator;
            this.init();
        }

        init() {
            this.bindEvents();
        }

        bindEvents() {
            // Кнопка получения текущей локации
            $(document).on('click', '.rm-get-location', (e) => this.getCurrentLocation(e));
            
            // Сохранение локации
            $(document).on('click', '.rm-save-location', (e) => this.saveLocation(e));
        }

        getCurrentLocation(e) {
            e.preventDefault();
            
            const $button = $(e.target);
            const $field = $button.closest('.rm-location-field');
            
            if (!this.isSupported) {
                this.showMessage(rm_i18n.geolocation_not_supported, 'error');
                return;
            }

            $button.prop('disabled', true).text(rm_i18n.getting_location);

            const options = {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 60000
            };

            navigator.geolocation.getCurrentPosition(
                (position) => this.handleLocationSuccess(position, $field),
                (error) => this.handleLocationError(error, $field),
                options
            );
        }

        handleLocationSuccess(position, $field) {
            const coords = position.coords;
            this.currentPosition = {
                lat: coords.latitude,
                lng: coords.longitude,
                accuracy: coords.accuracy,
                timestamp: position.timestamp
            };

            // Обновляем поля формы
            $field.find('input[name*="[lat]"]').val(this.currentPosition.lat);
            $field.find('input[name*="[lng]"]').val(this.currentPosition.lng);

            // Показываем точность
            this.showMessage(
                rm_i18n.location_found.replace('{{accuracy}}', Math.round(this.currentPosition.accuracy)) + ' meters',
                'success'
            );

            // Активируем кнопку сохранения
            $field.find('.rm-save-location').prop('disabled', false);

            // Пытаемся получить адрес по координатам (геокодирование)
            this.reverseGeocode(this.currentPosition.lat, this.currentPosition.lng, $field);
        }

        handleLocationError(error, $field) {
            const $button = $field.find('.rm-get-location');
            $button.prop('disabled', false).text(rm_i18n.get_current_location);

            let message = rm_i18n.location_error;
            
            switch (error.code) {
                case error.PERMISSION_DENIED:
                    message = rm_i18n.location_permission_denied;
                    break;
                case error.POSITION_UNAVAILABLE:
                    message = rm_i18n.position_unavailable;
                    break;
                case error.TIMEOUT:
                    message = rm_i18n.location_timeout;
                    break;
            }

            this.showMessage(message, 'error');
        }

        reverseGeocode(lat, lng, $field) {
            // Простая реализация геокодирования
            // В реальном приложении здесь был бы вызов к Google Maps API
            const address = `Lat: ${lat.toFixed(6)}, Lng: ${lng.toFixed(6)}`;
            $field.find('input[name*="[address]"]').val(address);
        }

        saveLocation(e) {
            e.preventDefault();
            
            const $button = $(e.target);
            const $field = $button.closest('.rm-location-field');
            const reportId = $button.data('report-id');

            if (!this.currentPosition) {
                this.showMessage(rm_i18n.no_location_data, 'error');
                return;
            }

            const locationData = {
                address: $field.find('input[name*="[address]"]').val(),
                lat: this.currentPosition.lat,
                lng: this.currentPosition.lng,
                accuracy: this.currentPosition.accuracy
            };

            $button.prop('disabled', true).text(rm_i18n.saving);

            $.ajax({
                url: rm_frontend.ajax_url,
                type: 'POST',
                data: {
                    action: 'rm_save_location',
                    report_id: reportId,
                    ...locationData,
                    nonce: rm_frontend.nonce
                },
                success: (response) => {
                    if (response.success) {
                        this.showMessage(response.data, 'success');
                    } else {
                        this.showMessage(response.data, 'error');
                    }
                },
                error: () => {
                    this.showMessage(rm_i18n.operation_error, 'error');
                },
                complete: () => {
                    $button.prop('disabled', false).text(rm_i18n.save_location);
                }
            });
        }

        showMessage(message, type) {
            const $message = $(`<div class="rm-message rm-message-${type}">${message}</div>`);
            $('.rm-report-builder').prepend($message);
            
            setTimeout(() => {
                $message.fadeOut(() => $message.remove());
            }, 5000);
        }
    }

    $(document).ready(() => {
        new GeolocationManager();
    });

})(jQuery);