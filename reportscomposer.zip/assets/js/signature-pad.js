// Интеграция с Signature Pad
(function($) {
    'use strict';

    class SignatureManager {
        constructor() {
            this.canvas = null;
            this.signaturePad = null;
            this.init();
        }

        init() {
            this.bindEvents();
        }

        bindEvents() {
            // Инициализация при появлении секции подписи
            $(document).on('click', '#rm-preview-report', () => this.initSignaturePad());
            
            // Очистка подписи
            $(document).on('click', '#rm-clear-signature', (e) => this.clearSignature(e));
        }

        initSignaturePad() {
            if (this.signaturePad) return;

            this.canvas = document.getElementById('rm-signature-canvas');
            if (!this.canvas) return;

            // Настройка canvas
            this.canvas.width = this.canvas.offsetWidth;
            this.canvas.height = 200;

            this.signaturePad = new SignaturePad(this.canvas, {
                minWidth: 1,
                maxWidth: 3,
                penColor: '#000',
                backgroundColor: '#fff'
            });

            // Обновление скрытого поля при изменении подписи
            this.signaturePad.onEnd = () => {
                this.updateSignatureData();
            };

            $('.rm-signature-section').show();
        }

        clearSignature(e) {
            e.preventDefault();
            if (this.signaturePad) {
                this.signaturePad.clear();
                this.updateSignatureData();
            }
        }

        updateSignatureData() {
            if (this.signaturePad && !this.signaturePad.isEmpty()) {
                const data = this.signaturePad.toDataURL();
                $('#rm-signature-data').val(data);
            } else {
                $('#rm-signature-data').val('');
            }
        }
    }

    $(document).ready(() => {
        new SignatureManager();
    });

})(jQuery);