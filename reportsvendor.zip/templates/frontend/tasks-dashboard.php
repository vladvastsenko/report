<?php
/**
 * Template: Tasks Dashboard
 */
if (!defined('ABSPATH')) exit;

$task_manager = new RM_Task_Manager();
$filters = array(
    'status' => isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '',
    'priority' => isset($_GET['priority']) ? sanitize_text_field($_GET['priority']) : '',
    'assigned_to' => isset($_GET['assigned_to']) ? sanitize_text_field($_GET['assigned_to']) : ''
);

$tasks = $task_manager->get_user_tasks(get_current_user_id(), $filters);
$task_stats = $this->get_task_stats(get_current_user_id());
?>

<div class="rm-tasks-dashboard">
    <header class="rm-tasks-header">
        <h1><?php _e('Task Management', 'report-manager'); ?></h1>
        <button type="button" class="rm-button rm-button-primary" id="rm-create-task">
            <?php _e('Create New Task', 'report-manager'); ?>
        </button>
    </header>

    <!-- Статистика -->
    <div class="rm-task-stats">
        <div class="rm-stat-card">
            <div class="rm-stat-number"><?php echo $task_stats['total']; ?></div>
            <div class="rm-stat-label"><?php _e('Total Tasks', 'report-manager'); ?></div>
        </div>
        
        <div class="rm-stat-card">
            <div class="rm-stat-number"><?php echo $task_stats['pending']; ?></div>
            <div class="rm-stat-label"><?php _e('Pending', 'report-manager'); ?></div>
        </div>
        
        <div class="rm-stat-card">
            <div class="rm-stat-number"><?php echo $task_stats['in_progress']; ?></div>
            <div class="rm-stat-label"><?php _e('In Progress', 'report-manager'); ?></div>
        </div>
        
        <div class="rm-stat-card">
            <div class="rm-stat-number"><?php echo $task_stats['completed']; ?></div>
            <div class="rm-stat-label"><?php _e('Completed', 'report-manager'); ?></div>
        </div>
    </div>

    <!-- Фильтры -->
    <div class="rm-task-filters">
        <form method="get" class="rm-filter-form">
            <input type="hidden" name="rm_page" value="tasks">
            
            <select name="status">
                <option value=""><?php _e('All Statuses', 'report-manager'); ?></option>
                <option value="pending" <?php selected($filters['status'], 'pending'); ?>><?php _e('Pending', 'report-manager'); ?></option>
                <option value="in_progress" <?php selected($filters['status'], 'in_progress'); ?>><?php _e('In Progress', 'report-manager'); ?></option>
                <option value="review" <?php selected($filters['status'], 'review'); ?>><?php _e('Under Review', 'report-manager'); ?></option>
                <option value="completed" <?php selected($filters['status'], 'completed'); ?>><?php _e('Completed', 'report-manager'); ?></option>
            </select>
            
            <select name="priority">
                <option value=""><?php _e('All Priorities', 'report-manager'); ?></option>
                <option value="low" <?php selected($filters['priority'], 'low'); ?>><?php _e('Low', 'report-manager'); ?></option>
                <option value="medium" <?php selected($filters['priority'], 'medium'); ?>><?php _e('Medium', 'report-manager'); ?></option>
                <option value="high" <?php selected($filters['priority'], 'high'); ?>><?php _e('High', 'report-manager'); ?></option>
                <option value="urgent" <?php selected($filters['priority'], 'urgent'); ?>><?php _e('Urgent', 'report-manager'); ?></option>
            </select>
            
            <select name="assigned_to">
                <option value=""><?php _e('All Assignees', 'report-manager'); ?></option>
                <option value="me" <?php selected($filters['assigned_to'], 'me'); ?>><?php _e('Assigned to Me', 'report-manager'); ?></option>
                <option value="unassigned" <?php selected($filters['assigned_to'], 'unassigned'); ?>><?php _e('Unassigned', 'report-manager'); ?></option>
            </select>
            
            <button type="submit" class="rm-button"><?php _e('Apply Filters', 'report-manager'); ?></button>
            <a href="?rm_page=tasks" class="rm-button rm-button-secondary"><?php _e('Reset', 'report-manager'); ?></a>
        </form>
    </div>

    <!-- Список задач -->
    <div class="rm-tasks-list">
        <?php if ($tasks): ?>
            <?php foreach ($tasks as $task): ?>
                <div class="rm-task-card" data-task-id="<?php echo $task->id; ?>">
                    <div class="rm-task-header">
                        <h3 class="rm-task-title">
                            <a href="<?php echo $this->get_task_url($task->id); ?>">
                                <?php echo esc_html($task->title); ?>
                            </a>
                        </h3>
                        <div class="rm-task-meta">
                            <span class="rm-task-priority rm-priority-<?php echo $task->priority; ?>">
                                <?php echo $this->get_priority_label($task->priority); ?>
                            </span>
                            <span class="rm-task-status rm-status-<?php echo $task->status; ?>">
                                <?php echo $this->get_status_label($task->status); ?>
                            </span>
                        </div>
                    </div>
                    
                    <div class="rm-task-body">
                        <p class="rm-task-description"><?php echo wp_trim_words(wp_strip_all_tags($task->description), 20); ?></p>
                        
                        <div class="rm-task-info">
                            <span class="rm-task-group"><?php echo esc_html($task->group_name); ?></span>
                            <?php if ($task->project_name): ?>
                                <span class="rm-task-project"><?php echo esc_html($task->project_name); ?></span>
                            <?php endif; ?>
                            
                            <?php if ($task->due_date): ?>
                                <span class="rm-task-due-date <?php echo $this->get_due_date_class($task->due_date, $task->status); ?>">
                                    <?php echo date_i18n(get_option('date_format'), strtotime($task->due_date)); ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="rm-task-footer">
                        <div class="rm-task-assignee">
                            <?php if ($task->assigned_to_name): ?>
                                <?php _e('Assigned to:', 'report-manager'); ?> 
                                <?php echo esc_html($task->assigned_to_name); ?>
                            <?php else: ?>
                                <span class="rm-unassigned"><?php _e('Unassigned', 'report-manager'); ?></span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="rm-task-actions">
                            <button type="button" class="rm-task-action rm-change-status" 
                                    data-task-id="<?php echo $task->id; ?>"
                                    data-current-status="<?php echo $task->status; ?>">
                                <?php _e('Change Status', 'report-manager'); ?>
                            </button>
                            
                            <?php if ($task->comment_count > 0): ?>
                                <span class="rm-comment-count">
                                    <?php echo $task->comment_count; ?> 
                                    <?php _e('comments', 'report-manager'); ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="rm-no-tasks">
                <p><?php _e('No tasks found matching your criteria.', 'report-manager'); ?></p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Модальное окно создания задачи -->
<div id="rm-create-task-modal" class="rm-modal" style="display: none;">
    <div class="rm-modal-content">
        <h2><?php _e('Create New Task', 'report-manager'); ?></h2>
        <?php include RM_PLUGIN_PATH . 'templates/frontend/task-form.php'; ?>
    </div>
</div>