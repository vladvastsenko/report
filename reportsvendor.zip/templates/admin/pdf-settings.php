<?php
/**
 * Template: PDF Settings with Plugin Integration
 */
if (!defined('ABSPATH')) exit;

$pdf_generator = new RM_PDF_Generator();
$engine_info = $pdf_generator->get_engine_info();
$available_plugins = $engine_info['available_plugins'];
$active_plugin = $engine_info['active_plugin'];

// Обработка сохранения настроек
if (isset($_POST['rm_pdf_settings_nonce']) && wp_verify_nonce($_POST['rm_pdf_settings_nonce'], 'rm_save_pdf_settings')) {
    if (isset($_POST['rm_preferred_plugin'])) {
        $pdf_integrations = new RM_PDF_Integrations();
        $pdf_integrations->set_preferred_plugin(sanitize_text_field($_POST['rm_preferred_plugin']));
    }
    
    if (isset($_POST['rm_pdf_defaults'])) {
        update_option('rm_pdf_default_settings', array_map('sanitize_text_field', $_POST['rm_pdf_defaults']));
    }
    
    echo '<div class="notice notice-success"><p>' . __('Settings saved successfully!', 'report-manager') . '</p></div>';
}

$default_settings = get_option('rm_pdf_default_settings', array());
?>

<div class="wrap">
    <h1><?php _e('PDF Settings - Report Manager', 'report-manager'); ?></h1>
    
    <form method="post" action="">
        <?php wp_nonce_field('rm_save_pdf_settings', 'rm_pdf_settings_nonce'); ?>
        
        <!-- Текущий статус -->
        <div class="card">
            <h2><?php _e('Current PDF Configuration', 'report-manager'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th><?php _e('Active Engine', 'report-manager'); ?></th>
                    <td>
                        <strong>
                            <?php if ($engine_info['current_engine'] === 'plugin' && $active_plugin): ?>
                                <?php echo esc_html($active_plugin['name']); ?>
                                <span class="dashicons dashicons-yes" style="color: #46b450;"></span>
                            <?php else: ?>
                                <?php _e('Built-in DomPDF', 'report-manager'); ?>
                                <span class="dashicons dashicons-admin-tools"></span>
                            <?php endif; ?>
                        </strong>
                    </td>
                </tr>
                
                <?php if ($active_plugin): ?>
                <tr>
                    <th><?php _e('Plugin Status', 'report-manager'); ?></th>
                    <td>
                        <span class="rm-status-active"><?php _e('Active', 'report-manager'); ?></span>
                    </td>
                </tr>
                <?php endif; ?>
            </table>
        </div>

        <!-- Выбор плагина PDF -->
        <div class="card">
            <h2><?php _e('PDF Plugin Selection', 'report-manager'); ?></h2>
            <p class="description">
                <?php _e('Report Manager will automatically detect and use available PDF plugins. You can manually select your preferred plugin below.', 'report-manager'); ?>
            </p>
            
            <table class="form-table">
                <tr>
                    <th><?php _e('Preferred PDF Plugin', 'report-manager'); ?></th>
                    <td>
                        <select name="rm_preferred_plugin" class="regular-text">
                            <option value="auto"><?php _e('Auto-detect (Recommended)', 'report-manager'); ?></option>
                            
                            <?php if (!empty($available_plugins)): ?>
                                <optgroup label="<?php _e('Available Plugins', 'report-manager'); ?>">
                                <?php foreach ($available_plugins as $slug => $plugin): ?>
                                    <option value="<?php echo esc_attr($slug); ?>" 
                                        <?php selected($active_plugin['name'] ?? '', $plugin['name']); ?>>
                                        <?php echo esc_html($plugin['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                                </optgroup>
                            <?php endif; ?>
                            
                            <optgroup label="<?php _e('Built-in Engine', 'report-manager'); ?>">
                                <option value="dompdf" <?php selected($engine_info['current_engine'], 'dompdf'); ?>>
                                    <?php _e('Built-in DomPDF', 'report-manager'); ?>
                                </option>
                            </optgroup>
                        </select>
                        <p class="description">
                            <?php _e('Select "Auto-detect" to automatically use the best available PDF plugin.', 'report-manager'); ?>
                        </p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- Доступные плагины -->
        <?php if (!empty($available_plugins)): ?>
        <div class="card">
            <h2><?php _e('Detected PDF Plugins', 'report-manager'); ?></h2>
            <div class="rm-plugins-list">
                <?php foreach ($available_plugins as $slug => $plugin): ?>
                    <div class="rm-plugin-card <?php echo ($active_plugin['name'] ?? '') === $plugin['name'] ? 'rm-plugin-active' : ''; ?>">
                        <h3><?php echo esc_html($plugin['name']); ?></h3>
                        <div class="rm-plugin-status">
                            <?php if (($active_plugin['name'] ?? '') === $plugin['name']): ?>
                                <span class="rm-status-active"><?php _e('Active', 'report-manager'); ?></span>
                            <?php else: ?>
                                <span class="rm-status-available"><?php _e('Available', 'report-manager'); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php else: ?>
        <div class="card">
            <h2><?php _e('PDF Plugins', 'report-manager'); ?></h2>
            <p><?php _e('No external PDF plugins detected. The built-in DomPDF engine will be used.', 'report-manager'); ?></p>
            
            <h3><?php _e('Recommended PDF Plugins', 'report-manager'); ?></h3>
            <ul>
                <li><a href="<?php echo admin_url('plugin-install.php?s=PDF+Generator+for+WP&tab=search&type=term'); ?>" target="_blank">
                    PDF Generator for WP
                </a></li>
                <li><a href="<?php echo admin_url('plugin-install.php?s=DK+PDF&tab=search&type=term'); ?>" target="_blank">
                    DK PDF
                </a></li>
                <li><a href="<?php echo admin_url('plugin-install.php?s=WP+HTML+to+PDF&tab=search&type=term'); ?>" target="_blank">
                    WP HTML to PDF
                </a></li>
            </ul>
        </div>
        <?php endif; ?>

        <!-- Настройки PDF по умолчанию -->
        <div class="card">
            <h2><?php _e('Default PDF Settings', 'report-manager'); ?></h2>
            
            <table class="form-table">
                <tr>
                    <th><?php _e('Paper Size', 'report-manager'); ?></th>
                    <td>
                        <select name="rm_pdf_defaults[paper_size]">
                            <option value="A4" <?php selected($default_settings['paper_size'] ?? 'A4', 'A4'); ?>>A4</option>
                            <option value="A3" <?php selected($default_settings['paper_size'] ?? 'A4', 'A3'); ?>>A3</option>
                            <option value="letter" <?php selected($default_settings['paper_size'] ?? 'A4', 'letter'); ?>>Letter</option>
                            <option value="legal" <?php selected($default_settings['paper_size'] ?? 'A4', 'legal'); ?>>Legal</option>
                        </select>
                    </td>
                </tr>
                
                <tr>
                    <th><?php _e('Orientation', 'report-manager'); ?></th>
                    <td>
                        <select name="rm_pdf_defaults[orientation]">
                            <option value="portrait" <?php selected($default_settings['orientation'] ?? 'portrait', 'portrait'); ?>>Portrait</option>
                            <option value="landscape" <?php selected($default_settings['orientation'] ?? 'portrait', 'landscape'); ?>>Landscape</option>
                        </select>
                    </td>
                </tr>
                
                <tr>
                    <th><?php _e('Font Family', 'report-manager'); ?></th>
                    <td>
                        <select name="rm_pdf_defaults[font_family]">
                            <option value="Arial" <?php selected($default_settings['font_family'] ?? 'Arial', 'Arial'); ?>>Arial</option>
                            <option value="Helvetica" <?php selected($default_settings['font_family'] ?? 'Arial', 'Helvetica'); ?>>Helvetica</option>
                            <option value="Times" <?php selected($default_settings['font_family'] ?? 'Arial', 'Times'); ?>>Times New Roman</option>
                            <option value="Courier" <?php selected($default_settings['font_family'] ?? 'Arial', 'Courier'); ?>>Courier</option>
                        </select>
                    </td>
                </tr>
            </table>
        </div>

        <?php submit_button(__('Save Settings', 'report-manager')); ?>
    </form>
</div>

<style>
.rm-plugins-list {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 15px;
    margin-top: 15px;
}

.rm-plugin-card {
    background: #f8f9fa;
    border: 1px solid #e0e0e0;
    border-radius: 8px;
    padding: 20px;
    position: relative;
}

.rm-plugin-active {
    border-color: #0073aa;
    background: #f0f7ff;
}

.rm-plugin-card h3 {
    margin: 0 0 10px 0;
    color: #333;
}

.rm-plugin-status {
    position: absolute;
    top: 15px;
    right: 15px;
}

.rm-status-active {
    background: #46b450;
    color: white;
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 0.8em;
    font-weight: bold;
}

.rm-status-available {
    background: #f0f0f0;
    color: #666;
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 0.8em;
}
</style>