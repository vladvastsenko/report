# Report Manager for WordPress

Comprehensive reporting and task management system for WordPress with multi-language support.

## Features

- 📊 **Advanced Reporting System** - Drag & drop report builder with customizable templates
- 👥 **Group Management** - Hierarchical user groups with different permission levels
- 📋 **Task Management** - Complete task tracking with comments and notifications
- 🌍 **Multi-language** - Support for Russian, English, Finnish, and Swedish
- 📄 **PDF Export** - Customizable PDF generation with headers, footers, and logos
- 📧 **Email Integration** - Send reports via email with PDF attachments
- 🔗 **Temporary Links** - Share reports with time-limited access links
- 🔐 **Membership Integration** - Seamless integration with Paid Memberships Pro
- 📱 **Responsive Design** - Works perfectly on desktop and mobile devices

## Requirements

- WordPress 5.8 or higher
- PHP 7.4 or higher
- Paid Memberships Pro plugin

## Installation

1. Upload the plugin files to `/wp-content/plugins/report-manager`
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Ensure Paid Memberships Pro is installed and activated
4. Configure the plugin settings in Report Manager > Settings

## Languages

- Russian (ru_RU)
- English (en_US) 
- Finnish (fi_FI)
- Swedish (sv_SE)

## Support

For support and documentation, visit our [support portal](https://example.com/support).

## License

This plugin is licensed under GPL v2 or later.