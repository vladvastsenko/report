<?php
/**
 * Plugin Name: Report Manager
 * Description: Comprehensive reporting and task management system for WordPress
 * Version: 1.0.0
 * Author: Your Name
 * Text Domain: report-manager
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

// Защита от прямого доступа
defined('ABSPATH') || exit;

// Константы плагина
define('RM_PLUGIN_URL', plugin_dir_url(__FILE__));
define('RM_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('RM_PLUGIN_VERSION', '1.0.0');
define('RM_DB_VERSION', '1.0.0');

// Регистрация хуков активации/деактивации
register_activation_hook(__FILE__, array('RM_Report_Activator', 'activate'));
register_deactivation_hook(__FILE__, array('RM_Report_Activator', 'deactivate'));
register_uninstall_hook(__FILE__, array('RM_Report_Activator', 'uninstall'));

// Основной класс плагина
class ReportManager {
    
    private static $instance = null;
    
    // Компоненты системы
    private $database;
    private $roles;
    private $post_types;
    private $groups;
    private $invitations;
    private $pmpro_integration;
    private $user_dashboard;
    private $templates;
    private $field_types;
    private $report_builder;
    private $pdf_generator;
    private $export_handler;
    private $email_handler;
    private $task_manager;
    private $task_notifications;
    private $geolocation;
    private $i18n;
    private $optimizer;
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
    }
    
    private function load_dependencies() {
        // Основные компоненты
        require_once RM_PLUGIN_PATH . 'includes/class-report-activator.php'; // НОВЫЙ ФАЙЛ
        require_once RM_PLUGIN_PATH . 'includes/class-database.php';
        require_once RM_PLUGIN_PATH . 'includes/class-roles.php';
        require_once RM_PLUGIN_PATH . 'includes/class-post-types.php';
        
        // Система пользователей и групп
        require_once RM_PLUGIN_PATH . 'includes/class-groups.php';
        require_once RM_PLUGIN_PATH . 'includes/class-invitations.php';
        require_once RM_PLUGIN_PATH . 'includes/class-pmpro-integration.php';
        
        // Фронтенд
        require_once RM_PLUGIN_PATH . 'includes/class-user-dashboard.php';
        
        // Отчеты и шаблоны
        require_once RM_PLUGIN_PATH . 'includes/class-templates.php';
        require_once RM_PLUGIN_PATH . 'includes/class-field-types.php';
        require_once RM_PLUGIN_PATH . 'includes/class-report-builder.php';
        
        // Экспорт и PDF
        require_once RM_PLUGIN_PATH . 'includes/class-pdf-integrations.php';
        require_once RM_PLUGIN_PATH . 'includes/class-pdf-fallback.php';
        require_once RM_PLUGIN_PATH . 'includes/class-pdf-generator.php';
        require_once RM_PLUGIN_PATH . 'includes/class-export-handler.php';
        require_once RM_PLUGIN_PATH . 'includes/class-email-handler.php';
        
        // Задачи
        require_once RM_PLUGIN_PATH . 'includes/class-task-manager.php';
        require_once RM_PLUGIN_PATH . 'includes/class-task-notifications.php';
        
        // Дополнительные модули
        require_once RM_PLUGIN_PATH . 'includes/class-geolocation.php';
        require_once RM_PLUGIN_PATH . 'includes/class-i18n.php';
        require_once RM_PLUGIN_PATH . 'includes/class-optimizer.php';
        
        // Админ интерфейсы
        if (is_admin()) {
            require_once RM_PLUGIN_PATH . 'includes/admin/class-admin-menu.php';
            require_once RM_PLUGIN_PATH . 'includes/admin/class-admin-templates.php';
            require_once RM_PLUGIN_PATH . 'includes/admin/class-admin-groups.php';
        }
        
        // Инициализация компонентов
        $this->database = new RM_Database();
        $this->roles = new RM_Roles();
        $this->post_types = new RM_Post_Types();
        $this->groups = new RM_Groups();
        $this->invitations = new RM_Invitations();
        $this->pmpro_integration = new RM_PMPro_Integration();
        $this->user_dashboard = new RM_User_Dashboard();
        $this->templates = new RM_Templates();
        $this->field_types = new RM_Field_Types();
        $this->report_builder = new RM_Report_Builder();
        $this->pdf_generator = new RM_PDF_Generator();
        $this->export_handler = new RM_Export_Handler();
        $this->email_handler = new RM_Email_Handler();
        $this->task_manager = new RM_Task_Manager();
        $this->task_notifications = new RM_Task_Notifications();
        $this->geolocation = new RM_Geolocation();
        $this->i18n = new RM_I18n();
        $this->optimizer = new RM_Optimizer();
    }
    
    private function init_hooks() {
        add_action('plugins_loaded', array($this, 'load_textdomain'));
        add_action('init', array($this, 'init'));
    }
    
    public function load_textdomain() {
        load_plugin_textdomain('report-manager', false, dirname(plugin_basename(__FILE__)) . '/languages/');
    }
    
    public function init() {
        // Основная инициализация компонентов
        $this->database->create_tables();
        $this->roles->setup_roles();
        $this->post_types->register_post_types();
        $this->post_types->register_taxonomies();
    }
    
    // Геттеры для всех компонентов
    public function database() { return $this->database; }
    public function roles() { return $this->roles; }
    public function post_types() { return $this->post_types; }
    public function groups() { return $this->groups; }
    public function invitations() { return $this->invitations; }
    public function pmpro_integration() { return $this->pmpro_integration; }
    public function user_dashboard() { return $this->user_dashboard; }
    public function templates() { return $this->templates; }
    public function field_types() { return $this->field_types; }
    public function report_builder() { return $this->report_builder; }
    public function pdf_generator() { return $this->pdf_generator; }
    public function export_handler() { return $this->export_handler; }
    public function email_handler() { return $this->email_handler; }
    public function task_manager() { return $this->task_manager; }
    public function task_notifications() { return $this->task_notifications; }
    public function geolocation() { return $this->geolocation; }
    public function i18n() { return $this->i18n; }
    public function optimizer() { return $this->optimizer; }
}

// Инициализация плагина
function report_manager() {
    return ReportManager::get_instance();
}

// Запуск
add_action('plugins_loaded', 'report_manager');

// Хелпер функции для внешнего использования
if (!function_exists('rm_get_report_url')) {
    function rm_get_report_url($report_id) {
        return home_url("/reports/{$report_id}/");
    }
}

if (!function_exists('rm_get_task_url')) {
    function rm_get_task_url($task_id) {
        return home_url("/tasks/{$task_id}/");
    }
}

if (!function_exists('rm_user_can_manage_reports')) {
    function rm_user_can_manage_reports($user_id = null) {
        $user_id = $user_id ?: get_current_user_id();
        $user = get_userdata($user_id);
        
        return $user && (in_array('rm_super_user', $user->roles) || 
               in_array('rm_group_user', $user->roles) ||
               current_user_can('manage_options'));
    }
}