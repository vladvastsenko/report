<?php

class RM_Activator {
    
    public static function activate() {
        // Создаем экземпляры классов для активации
        $database = new RM_Database();
        $roles = new RM_Roles();
        $post_types = new RM_Post_Types();
        
        // Выполняем setup
        $database->create_tables();
        $roles->setup_roles();
        $post_types->register_post_types();
        $post_types->register_taxonomies();
        
        // Чистим permalinks
        flush_rewrite_rules();
        
        // Создаем стандартные страницы если нужно
        self::create_default_pages();
    }
    
    public static function deactivate() {
        // Чистим permalinks при деактивации
        flush_rewrite_rules();
        
        // Убираем scheduled tasks если есть
        wp_clear_scheduled_hook('rm_daily_maintenance');
    }
    
    private static function create_default_pages() {
        // Здесь будем создавать страницы ЛК пользователя
        // Пока заглушка для следующего этапа
    }
}