<?php

class RM_Geolocation {
    
    public function __construct() {
        add_action('wp_ajax_rm_save_location', array($this, 'ajax_save_location'));
        add_action('wp_ajax_rm_get_current_location', array($this, 'ajax_get_current_location'));
    }
    
    /**
     * Получение текущей геолокации пользователя
     */
    public function get_current_location() {
        // Этот метод будет вызываться из JavaScript
        // Реальная реализация требует HTTPS и разрешения пользователя
        return array(
            'success' => false,
            'message' => __('Geolocation requires browser support and user permission', 'report-manager')
        );
    }
    
    /**
     * Сохранение геолокации для отчета
     */
    public function save_report_location($report_id, $location_data) {
        if (empty($location_data) {
            return false;
        }
        
        $sanitized_data = array(
            'address' => sanitize_text_field($location_data['address'] ?? ''),
            'lat' => floatval($location_data['lat'] ?? 0),
            'lng' => floatval($location_data['lng'] ?? 0),
            'accuracy' => floatval($location_data['accuracy'] ?? 0),
            'timestamp' => current_time('mysql')
        );
        
        update_post_meta($report_id, '_rm_report_location', $sanitized_data);
        
        return true;
    }
    
    /**
     * Получение геолокации отчета
     */
    public function get_report_location($report_id) {
        return get_post_meta($report_id, '_rm_report_location', true);
    }
    
    /**
     * Автоматическое определение адреса по координатам (Geocoding)
     */
    public function reverse_geocode($lat, $lng) {
        // Для использования этого метода нужен API ключ Google Maps
        // В бесплатной версии используем простое сообщение
        return array(
            'success' => false,
            'message' => __('Geocoding service requires API configuration', 'report-manager'),
            'address' => ''
        );
    }
    
    /**
     * AJAX: Сохранение локации
     */
    public function ajax_save_location() {
        check_ajax_referer('rm_frontend_actions', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(__('Authentication required', 'report-manager'));
        }
        
        $report_id = intval($_POST['report_id']);
        $location_data = array(
            'address' => sanitize_text_field($_POST['address']),
            'lat' => floatval($_POST['lat']),
            'lng' => floatval($_POST['lng']),
            'accuracy' => floatval($_POST['accuracy'] ?? 0)
        );
        
        $result = $this->save_report_location($report_id, $location_data);
        
        if ($result) {
            wp_send_json_success(__('Location saved successfully', 'report-manager'));
        } else {
            wp_send_json_error(__('Failed to save location', 'report-manager'));
        }
    }
    
    /**
     * AJAX: Получение текущей локации
     */
    public function ajax_get_current_location() {
        check_ajax_referer('rm_frontend_actions', 'nonce');
        
        // В реальной реализации здесь был бы вызов к геолокации
        // Но для безопасности и простоты возвращаем сообщение
        wp_send_json_success(array(
            'message' => __('Click the button to get your current location', 'report-manager'),
            'requires_user_action' => true
        ));
    }
}