<?php

class RM_Task_Notifications {
    
    /**
     * Отправка уведомления о задаче
     */
    public function send_task_notification($task_id, $action, $extra_data = array()) {
        $task_manager = new RM_Task_Manager();
        $task = $task_manager->get_task($task_id);
        
        if (!$task) {
            return false;
        }
        
        $recipients = $this->get_notification_recipients($task, $action);
        
        foreach ($recipients as $recipient) {
            $this->send_single_notification($recipient, $task, $action, $extra_data);
        }
        
        return true;
    }
    
    /**
     * Получение получателей уведомлений
     */
    private function get_notification_recipients($task, $action) {
        $recipients = array();
        
        switch ($action) {
            case 'created':
                // Создателю и назначенному пользователю
                if ($task->assigned_to && $task->assigned_to != $task->created_by) {
                    $recipients[] = $task->assigned_to;
                }
                $recipients[] = $task->created_by;
                break;
                
            case 'status_changed':
                // Создателю и назначенному пользователю
                $recipients[] = $task->created_by;
                if ($task->assigned_to) {
                    $recipients[] = $task->assigned_to;
                }
                break;
                
            case 'comment_added':
                // Все участники обсуждения задачи
                $recipients = $this->get_task_participants($task->id);
                break;
                
            case 'assigned':
                // Новому назначенному пользователю
                if ($task->assigned_to) {
                    $recipients[] = $task->assigned_to;
                }
                break;
        }
        
        // Убираем дубликаты
        $recipients = array_unique($recipients);
        
        // Получаем данные пользователей
        $users = array();
        foreach ($recipients as $user_id) {
            $user = get_userdata($user_id);
            if ($user) {
                $users[] = $user;
            }
        }
        
        return $users;
    }
    
    /**
     * Получение всех участников задачи
     */
    private function get_task_participants($task_id) {
        global $wpdb;
        
        $participants = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT user_id FROM {$wpdb->prefix}rm_task_comments WHERE task_id = %d
             UNION
             SELECT DISTINCT user_id FROM {$wpdb->prefix}rm_task_activities WHERE task_id = %d
             UNION
             SELECT created_by FROM {$wpdb->prefix}rm_tasks WHERE id = %d
             UNION
             SELECT assigned_to FROM {$wpdb->prefix}rm_tasks WHERE id = %d",
            $task_id, $task_id, $task_id, $task_id
        ));
        
        return array_filter($participants); // Убираем null значения
    }
    
    /**
     * Отправка одного уведомления
     */
    private function send_single_notification($user, $task, $action, $extra_data) {
        $subject = $this->get_notification_subject($task, $action);
        $message = $this->get_notification_message($user, $task, $action, $extra_data);
        
        $headers = array('Content-Type: text/html; charset=UTF-8');
        
        return wp_mail($user->user_email, $subject, $message, $headers);
    }
    
    /**
     * Получение темы уведомления
     */
    private function get_notification_subject($task, $action) {
        $site_name = get_bloginfo('name');
        $task_title = $task->title;
        
        $subjects = array(
            'created' => sprintf(__('New task assigned: %s - %s', 'report-manager'), $task_title, $site_name),
            'status_changed' => sprintf(__('Task status updated: %s - %s', 'report-manager'), $task_title, $site_name),
            'comment_added' => sprintf(__('New comment on task: %s - %s', 'report-manager'), $task_title, $site_name),
            'assigned' => sprintf(__('You have been assigned a task: %s - %s', 'report-manager'), $task_title, $site_name)
        );
        
        return $subjects[$action] ?? sprintf(__('Task notification: %s - %s', 'report-manager'), $task_title, $site_name);
    }
    
    /**
     * Получение сообщения уведомления
     */
    private function get_notification_message($user, $task, $action, $extra_data) {
        $task_url = $this->get_task_url($task->id);
        $site_name = get_bloginfo('name');
        
        ob_start();
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { border-bottom: 2px solid #0073aa; padding-bottom: 10px; margin-bottom: 20px; }
                .task-info { background: #f9f9f9; padding: 15px; border-radius: 5px; margin: 15px 0; }
                .button { display: inline-block; padding: 10px 20px; background: #0073aa; color: white; text-decoration: none; border-radius: 3px; }
                .footer { margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 12px; color: #666; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1><?php echo esc_html($site_name); ?></h1>
                </div>
                
                <div class="content">
                    <?php $this->render_notification_content($user, $task, $action, $extra_data); ?>
                    
                    <div class="task-info">
                        <h3><?php echo esc_html($task->title); ?></h3>
                        <p><strong><?php _e('Priority:', 'report-manager'); ?></strong> <?php echo $this->get_priority_label($task->priority); ?></p>
                        <p><strong><?php _e('Status:', 'report-manager'); ?></strong> <?php echo $this->get_status_label($task->status); ?></p>
                        <?php if ($task->due_date): ?>
                            <p><strong><?php _e('Due Date:', 'report-manager'); ?></strong> <?php echo date_i18n(get_option('date_format'), strtotime($task->due_date)); ?></p>
                        <?php endif; ?>
                    </div>
                    
                    <p>
                        <a href="<?php echo esc_url($task_url); ?>" class="button">
                            <?php _e('View Task', 'report-manager'); ?>
                        </a>
                    </p>
                </div>
                
                <div class="footer">
                    <p><?php _e('This email was sent from the task management system.', 'report-manager'); ?></p>
                </div>
            </div>
        </body>
        </html>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Рендер контента уведомления
     */
    private function render_notification_content($user, $task, $action, $extra_data) {
        $current_user = wp_get_current_user();
        
        switch ($action) {
            case 'created':
                echo '<p>' . sprintf(
                    __('Hello %s, a new task has been created and assigned to you.', 'report-manager'),
                    esc_html($user->display_name)
                ) . '</p>';
                break;
                
            case 'status_changed':
                echo '<p>' . sprintf(
                    __('Hello %s, the task "%s" status has been changed by %s.', 'report-manager'),
                    esc_html($user->display_name),
                    esc_html($task->title),
                    esc_html($current_user->display_name)
                ) . '</p>';
                break;
                
            case 'comment_added':
                echo '<p>' . sprintf(
                    __('Hello %s, a new comment has been added to task "%s" by %s.', 'report-manager'),
                    esc_html($user->display_name),
                    esc_html($task->title),
                    esc_html($current_user->display_name)
                ) . '</p>';
                
                if (!empty($extra_data['comment'])) {
                    echo '<div style="background: #f0f0f0; padding: 10px; margin: 10px 0; border-left: 3px solid #0073aa;">';
                    echo wp_kses_post(wpautop($extra_data['comment']));
                    echo '</div>';
                }
                break;
        }
    }
    
    /**
     * Получение URL задачи
     */
    private function get_task_url($task_id) {
        return home_url('/tasks/' . $task_id . '/');
    }
    
    /**
     * Получение метки приоритета
     */
    private function get_priority_label($priority) {
        $labels = array(
            'low' => __('Low', 'report-manager'),
            'medium' => __('Medium', 'report-manager'),
            'high' => __('High', 'report-manager'),
            'urgent' => __('Urgent', 'report-manager')
        );
        
        return $labels[$priority] ?? $priority;
    }
    
    /**
     * Получение метки статуса
     */
    private function get_status_label($status) {
        $labels = array(
            'pending' => __('Pending', 'report-manager'),
            'in_progress' => __('In Progress', 'report-manager'),
            'review' => __('Under Review', 'report-manager'),
            'completed' => __('Completed', 'report-manager')
        );
        
        return $labels[$status] ?? $status;
    }
}