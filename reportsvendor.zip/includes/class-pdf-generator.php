<?php

class RM_PDF_Generator {
    
    private $integrations;
    private $fallback;
    private $current_engine;
    
    public function __construct() {
        $this->integrations = new RM_PDF_Integrations();
        $this->fallback = new RM_PDF_Fallback();
        $this->set_current_engine();
    }
    
    /**
     * Установка текущего движка
     */
    private function set_current_engine() {
        if ($this->integrations->has_pdf_plugins()) {
            $this->current_engine = 'plugin';
        } else {
            $this->current_engine = 'dompdf';
        }
    }
    
    /**
     * Генерация PDF отчета
     */
    public function generate_report_pdf($report_id, $options = array()) {
        $report = get_post($report_id);
        if (!$report || $report->post_type !== 'rm_report') {
            return array(
                'success' => false,
                'error' => __('Report not found', 'report-manager')
            );
        }
        
        // Получаем данные отчета
        $report_data = get_post_meta($report_id, '_rm_report_data', true);
        $group_id = get_post_meta($report_id, '_rm_report_group', true);
        
        // Получаем настройки PDF
        $pdf_settings = $this->get_pdf_settings($group_id);
        $options = wp_parse_args($options, $pdf_settings);
        
        // Генерируем HTML контент
        $html_content = $this->generate_html_content($report, $report_data, $options);
        
        // Выбираем метод генерации
        if ($this->current_engine === 'plugin') {
            $result = $this->integrations->generate_pdf($html_content, $options);
        } else {
            $result = $this->fallback->generate_pdf($html_content, $options);
        }
        
        // Логируем генерацию
        if ($result['success'] ?? false) {
            $this->log_pdf_generation($report_id, $result['engine'] ?? 'unknown');
        }
        
        return $result;
    }
    
    /**
     * Генерация HTML контента для PDF
     */
    private function generate_html_content($report, $report_data, $options) {
        ob_start();
        
        // Заголовок PDF
        include RM_PLUGIN_PATH . 'templates/pdf/header.php';
        
        // Основной контент отчета
        include RM_PLUGIN_PATH . 'templates/pdf/report-template.php';
        
        // Подвал PDF
        include RM_PLUGIN_PATH . 'templates/pdf/footer.php';
        
        $content = ob_get_clean();
        
        // Применяем стили
        $content = $this->apply_pdf_styles($content, $options);
        
        return $content;
    }
    
    /**
     * Применение стилей к PDF
     */
    private function apply_pdf_styles($content, $options) {
        $styles = $this->get_pdf_styles($options);
        
        // Вставляем стили в head
        $content = str_replace('</head>', $styles . '</head>', $content);
        
        return $content;
    }
    
    /**
     * Получение стилей для PDF
     */
    private function get_pdf_styles($options) {
        ob_start();
        include RM_PLUGIN_PATH . 'templates/pdf/styles.php';
        return ob_get_clean();
    }
    
    /**
     * Получение настроек PDF
     */
    private function get_pdf_settings($group_id) {
        $default_settings = array(
            'paper_size' => 'A4',
            'orientation' => 'portrait',
            'font_family' => 'Arial',
            'font_size' => '12pt',
            'primary_color' => '#333333',
            'show_logo' => true,
            'show_page_numbers' => true,
            'margin_top' => '20',
            'margin_bottom' => '20',
            'margin_left' => '15',
            'margin_right' => '15'
        );
        
        // Если есть настройки группы, используем их
        if ($group_id) {
            $group_settings = $this->get_group_pdf_settings($group_id);
            if ($group_settings) {
                return wp_parse_args($group_settings, $default_settings);
            }
        }
        
        // Настройки по умолчанию из опций
        $saved_settings = get_option('rm_pdf_default_settings', array());
        return wp_parse_args($saved_settings, $default_settings);
    }
    
    /**
     * Получение настроек группы
     */
    private function get_group_pdf_settings($group_id) {
        global $wpdb;
        
        $settings = $wpdb->get_var($wpdb->prepare(
            "SELECT pdf_settings FROM {$wpdb->prefix}rm_groups WHERE id = %d",
            $group_id
        ));
        
        return $settings ? unserialize($settings) : false;
    }
    
    /**
     * Логирование генерации PDF
     */
    private function log_pdf_generation($report_id, $engine) {
        $logs = get_post_meta($report_id, '_rm_pdf_generation_logs', true);
        if (!is_array($logs)) {
            $logs = array();
        }
        
        $logs[] = array(
            'engine' => $engine,
            'generated_at' => current_time('mysql'),
            'generated_by' => get_current_user_id()
        );
        
        update_post_meta($report_id, '_rm_pdf_generation_logs', $logs);
    }
    
    /**
     * Получение информации о движках
     */
    public function get_engine_info() {
        $active_plugin = $this->integrations->get_active_plugin();
        
        return array(
            'current_engine' => $this->current_engine,
            'active_plugin' => $active_plugin,
            'available_plugins' => $this->integrations->get_available_plugins(),
            'fallback_available' => $this->fallback_available()
        );
    }
    
    /**
     * Проверка доступности fallback
     */
    private function fallback_available() {
        return true; // DomPDF всегда доступен через скачивание
    }
    
    /**
     * Генерация временной ссылки
     */
    public function generate_temporary_link($report_id, $expiry_hours = 24) {
        $token = wp_generate_password(32, false);
        $expiry = time() + ($expiry_hours * 3600);
        
        set_transient('rm_pdf_token_' . $token, array(
            'report_id' => $report_id,
            'expires' => $expiry
        ), $expiry_hours * 3600);
        
        return add_query_arg(array(
            'rm_pdf' => $token,
            'report' => $report_id
        ), home_url('/'));
    }
    
    /**
     * Обработка временной ссылки
     */
    public function handle_temporary_link($token) {
        $data = get_transient('rm_pdf_token_' . $token);
        
        if (!$data || $data['expires'] < time()) {
            return false;
        }
        
        $report_id = $data['report_id'];
        $pdf_data = $this->generate_report_pdf($report_id);
        
        if ($pdf_data['success'] && file_exists($pdf_data['filepath'])) {
            $this->force_download($pdf_data['filepath'], $pdf_data['filename']);
            exit;
        }
        
        return false;
    }
    
    /**
     * Принудительная загрузка файла
     */
    private function force_download($filepath, $filename) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($filepath));
        readfile($filepath);
        exit;
    }
}