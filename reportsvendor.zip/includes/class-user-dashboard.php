<?php

class RM_User_Dashboard {
    
    public function __construct() {
        add_action('init', array($this, 'add_rewrite_rules'));
        add_action('template_redirect', array($this, 'handle_frontend_pages'));
        add_filter('query_vars', array($this, 'add_query_vars'));
        
        add_shortcode('rm_dashboard', array($this, 'render_dashboard_shortcode'));
        add_shortcode('rm_report_builder', array($this, 'render_report_builder_shortcode'));
        
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));
    }
    
    /**
     * Добавляем rewrite rules для красивый URL
     */
    public function add_rewrite_rules() {
        add_rewrite_rule(
            '^reports/dashboard/?$',
            'index.php?rm_page=dashboard',
            'top'
        );
        
        add_rewrite_rule(
            '^reports/create/?$',
            'index.php?rm_page=create_report',
            'top'
        );
        
        add_rewrite_rule(
            '^reports/([^/]+)/?$',
            'index.php?rm_page=view_report&report_id=$matches[1]',
            'top'
        );
        
        add_rewrite_rule(
            '^reports/([^/]+)/edit/?$',
            'index.php?rm_page=edit_report&report_id=$matches[1]',
            'top'
        );
        
        flush_rewrite_rules();
    }
    
    public function add_query_vars($vars) {
        $vars[] = 'rm_page';
        $vars[] = 'report_id';
        return $vars;
    }
    
    /**
     * Обработка фронтенд страниц
     */
    public function handle_frontend_pages() {
        $rm_page = get_query_var('rm_page');
        
        if (!$rm_page) return;
        
        // Проверяем авторизацию
        if (!is_user_logged_in()) {
            auth_redirect();
            return;
        }
        
        // Проверяем доступ к модулю
        if (!$this->user_has_access()) {
            wp_die(__('You do not have access to the report system', 'report-manager'));
        }
        
        switch ($rm_page) {
            case 'dashboard':
                $this->render_dashboard();
                break;
                
            case 'create_report':
                $this->render_report_builder();
                break;
                
            case 'view_report':
                $this->render_view_report();
                break;
                
            case 'edit_report':
                $this->render_edit_report();
                break;
        }
        
        exit;
    }
    
    /**
     * Рендер главной страницы кабинета
     */
    public function render_dashboard() {
        $current_user = wp_get_current_user();
        $groups = new RM_Groups();
        $user_groups = $groups->get_user_groups($current_user->ID);
        
        // Получаем статистику
        $stats = $this->get_user_stats($current_user->ID);
        
        include RM_PLUGIN_PATH . 'templates/frontend/dashboard.php';
    }
    
    /**
     * Рендер конструктора отчетов
     */
    public function render_report_builder() {
        $templates = new RM_Templates();
        $available_templates = $templates->get_available_templates(get_current_user_id());
        
        // Получаем проекты пользователя
        $projects = $this->get_user_projects(get_current_user_id());
        
        include RM_PLUGIN_PATH . 'templates/frontend/report-builder.php';
    }
    
    /**
     * Рендер просмотра отчета
     */
    public function render_view_report() {
        $report_id = get_query_var('report_id');
        $report = get_post($report_id);
        
        if (!$report || $report->post_type !== 'rm_report') {
            wp_die(__('Report not found', 'report-manager'));
        }
        
        // Проверяем доступ к отчету
        if (!$this->user_can_view_report(get_current_user_id(), $report_id)) {
            wp_die(__('You do not have permission to view this report', 'report-manager'));
        }
        
        // Получаем данные отчета
        $report_data = $this->get_report_data($report_id);
        
        include RM_PLUGIN_PATH . 'templates/frontend/report-view.php';
    }
    
    /**
     * Получение статистики пользователя
     */
    private function get_user_stats($user_id) {
        global $wpdb;
        
        $stats = array(
            'total_reports' => 0,
            'reports_this_month' => 0,
            'signed_reports' => 0,
            'draft_reports' => 0
        );
        
        // Общее количество отчетов
        $stats['total_reports'] = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} 
             WHERE post_type = 'rm_report' AND post_author = %d",
            $user_id
        ));
        
        // Отчеты за этот месяц
        $stats['reports_this_month'] = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->posts} 
             WHERE post_type = 'rm_report' 
             AND post_author = %d 
             AND YEAR(post_date) = YEAR(CURDATE()) 
             AND MONTH(post_date) = MONTH(CURDATE())",
            $user_id
        ));
        
        // Подписанные отчеты
        $stats['signed_reports'] = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} 
             WHERE post_id IN (
                 SELECT ID FROM {$wpdb->posts} 
                 WHERE post_type = 'rm_report' AND post_author = %d
             ) 
             AND meta_key = '_rm_report_signed' 
             AND meta_value = '1'",
            $user_id
        ));
        
        $stats['draft_reports'] = $stats['total_reports'] - $stats['signed_reports'];
        
        return $stats;
    }
    
    /**
     * Получение проектов пользователя
     */
    private function get_user_projects($user_id) {
        global $wpdb;
        
        // Получаем группы пользователя
        $user_groups = $wpdb->get_col($wpdb->prepare(
            "SELECT group_id FROM {$wpdb->prefix}rm_user_groups WHERE user_id = %d",
            $user_id
        ));
        
        if (empty($user_groups)) return array();
        
        $placeholders = implode(',', array_fill(0, count($user_groups), '%d'));
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}rm_projects 
             WHERE group_id IN ($placeholders) 
             ORDER BY hierarchy_level, sort_order, name",
            $user_groups
        ));
    }
    
    /**
     * Проверка доступа к отчету
     */
    private function user_can_view_report($user_id, $report_id) {
        global $wpdb;
        
        // Автор отчета всегда может его просматривать
        $report_author = $wpdb->get_var($wpdb->prepare(
            "SELECT post_author FROM {$wpdb->posts} WHERE ID = %d",
            $report_id
        ));
        
        if ($report_author == $user_id) {
            return true;
        }
        
        // Проверяем доступ через группы
        $report_groups = $wpdb->get_col($wpdb->prepare(
            "SELECT group_id FROM {$wpdb->prefix}rm_user_groups 
             WHERE user_id = %d",
            $user_id
        ));
        
        $report_group = $wpdb->get_var($wpdb->prepare(
            "SELECT meta_value FROM {$wpdb->postmeta} 
             WHERE post_id = %d AND meta_key = '_rm_report_group'",
            $report_id
        ));
        
        return in_array($report_group, $report_groups);
    }
    
    /**
     * Получение данных отчета
     */
    private function get_report_data($report_id) {
        $report_data = get_post_meta($report_id, '_rm_report_data', true);
        return is_array($report_data) ? $report_data : array();
    }
    
    /**
     * Enqueue скрипты и стили для фронтенда
     */
    public function enqueue_frontend_scripts() {
        if (!is_page() || !$this->is_rm_page()) return;
        
        wp_enqueue_style(
            'rm-frontend-style',
            RM_PLUGIN_URL . 'assets/css/frontend.css',
            array(),
            RM_PLUGIN_VERSION
        );
        
        wp_enqueue_script(
            'rm-frontend-script',
            RM_PLUGIN_URL . 'assets/js/frontend.js',
            array('jquery', 'jquery-ui-sortable'),
            RM_PLUGIN_VERSION,
            true
        );
        
        // Для конструктора отчетов
        if (get_query_var('rm_page') === 'create_report') {
            wp_enqueue_script(
                'rm-drag-drop',
                RM_PLUGIN_URL . 'assets/js/drag-drop.js',
                array('rm-frontend-script'),
                RM_PLUGIN_VERSION,
                true
            );
            
            wp_enqueue_script(
                'rm-location',
                RM_PLUGIN_URL . 'assets/js/location.js',
                array('rm-frontend-script'),
                RM_PLUGIN_VERSION,
                true
            );
            
            wp_enqueue_script(
                'signature-pad',
                RM_PLUGIN_URL . 'assets/js/signature-pad.js',
                array(),
                '4.0.0',
                true
            );
            
            wp_enqueue_style(
                'rm-drag-drop-style',
                RM_PLUGIN_URL . 'assets/css/drag-drop.css',
                array('rm-frontend-style'),
                RM_PLUGIN_VERSION
            );
        }
        
        // Localize script
        wp_localize_script('rm-frontend-script', 'rm_frontend', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('rm_frontend_actions'),
            'i18n' => array(
                'confirm_delete' => __('Are you sure you want to delete this report?', 'report-manager'),
                'saving' => __('Saving...', 'report-manager'),
                'error' => __('Error occurred', 'report-manager')
            )
        ));
    }
    
    private function is_rm_page() {
        return get_query_var('rm_page') !== '';
    }
    
    private function user_has_access() {
        $user = wp_get_current_user();
        return in_array('rm_super_user', $user->roles) || 
               in_array('rm_group_user', $user->roles) ||
               current_user_can('manage_options');
    }
}