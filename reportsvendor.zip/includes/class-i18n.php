<?php

class RM_I18n {
    
    private $text_domain = 'report-manager';
    private $languages_path;
    
    public function __construct() {
        $this->languages_path = RM_PLUGIN_PATH . 'languages/';
        
        add_action('plugins_loaded', array($this, 'load_textdomain'));
        add_filter('plugin_locale', array($this, 'set_plugin_locale'), 10, 2);
        add_action('wp_ajax_rm_change_language', array($this, 'ajax_change_language'));
    }
    
    /**
     * Загрузка textdomain
     */
    public function load_textdomain() {
        load_plugin_textdomain(
            $this->text_domain,
            false,
            dirname(plugin_basename(RM_PLUGIN_PATH)) . '/languages/'
        );
        
        // Дополнительная загрузка для JavaScript переводов
        $this->load_js_translations();
    }
    
    /**
     * Установка локали для плагина
     */
    public function set_plugin_locale($locale, $domain) {
        if ($domain === $this->text_domain) {
            $user_language = $this->get_user_language();
            if ($user_language && $user_language !== $locale) {
                return $user_language;
            }
        }
        return $locale;
    }
    
    /**
     * Получение языка пользователя
     */
    public function get_user_language() {
        // Приоритеты: пользовательская настройка > язык браузера > язык сайта
        if (is_user_logged_in()) {
            $user_language = get_user_meta(get_current_user_id(), 'rm_user_language', true);
            if ($user_language) {
                return $user_language;
            }
        }
        
        // Язык браузера
        if (isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
            $browser_language = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
            $supported_languages = $this->get_supported_languages();
            
            if (in_array($browser_language, array_keys($supported_languages))) {
                return $supported_languages[$browser_language]['wp_locale'];
            }
        }
        
        // Язык сайта по умолчанию
        return get_locale();
    }
    
    /**
     * Поддерживаемые языки
     */
    public function get_supported_languages() {
        return array(
            'ru' => array(
                'code' => 'ru',
                'wp_locale' => 'ru_RU',
                'name' => 'Русский',
                'native_name' => 'Русский',
                'flag' => '🇷🇺'
            ),
            'en' => array(
                'code' => 'en',
                'wp_locale' => 'en_US',
                'name' => 'English',
                'native_name' => 'English',
                'flag' => '🇺🇸'
            ),
            'fi' => array(
                'code' => 'fi',
                'wp_locale' => 'fi_FI',
                'name' => 'Finnish',
                'native_name' => 'Suomi',
                'flag' => '🇫🇮'
            ),
            'sv' => array(
                'code' => 'sv',
                'wp_locale' => 'sv_SE',
                'name' => 'Swedish',
                'native_name' => 'Svenska',
                'flag' => '🇸🇪'
            )
        );
    }
    
    /**
     * Загрузка переводов для JavaScript
     */
    public function load_js_translations() {
        $translations = $this->get_js_translations();
        
        wp_localize_script('rm-frontend-script', 'rm_i18n', $translations);
        wp_localize_script('rm-admin-script', 'rm_i18n', $translations);
    }
    
    /**
     * Получение переводов для JavaScript
     */
    public function get_js_translations() {
        return array(
            // Общие фразы
            'save' => __('Save', 'report-manager'),
            'cancel' => __('Cancel', 'report-manager'),
            'delete' => __('Delete', 'report-manager'),
            'edit' => __('Edit', 'report-manager'),
            'view' => __('View', 'report-manager'),
            'confirm' => __('Confirm', 'report-manager'),
            'loading' => __('Loading...', 'report-manager'),
            'saving' => __('Saving...', 'report-manager'),
            
            // Сообщения
            'confirm_delete' => __('Are you sure you want to delete this?', 'report-manager'),
            'operation_success' => __('Operation completed successfully', 'report-manager'),
            'operation_error' => __('An error occurred', 'report-manager'),
            'no_data' => __('No data available', 'report-manager'),
            
            // Отчеты
            'create_report' => __('Create Report', 'report-manager'),
            'edit_report' => __('Edit Report', 'report-manager'),
            'delete_report' => __('Delete Report', 'report-manager'),
            'report_saved' => __('Report saved successfully', 'report-manager'),
            'report_deleted' => __('Report deleted successfully', 'report-manager'),
            'sign_report' => __('Sign Report', 'report-manager'),
            'report_signed' => __('Report signed successfully', 'report-manager'),
            
            // Задачи
            'create_task' => __('Create Task', 'report-manager'),
            'edit_task' => __('Edit Task', 'report-manager'),
            'delete_task' => __('Delete Task', 'report-manager'),
            'task_saved' => __('Task saved successfully', 'report-manager'),
            'change_status' => __('Change Status', 'report-manager'),
            'add_comment' => __('Add Comment', 'report-manager'),
            
            // Статусы
            'pending' => __('Pending', 'report-manager'),
            'in_progress' => __('In Progress', 'report-manager'),
            'review' => __('Under Review', 'report-manager'),
            'completed' => __('Completed', 'report-manager'),
            
            // Приоритеты
            'low' => __('Low', 'report-manager'),
            'medium' => __('Medium', 'report-manager'),
            'high' => __('High', 'report-manager'),
            'urgent' => __('Urgent', 'report-manager'),
            
            // Экспорт
            'export_pdf' => __('Export to PDF', 'report-manager'),
            'export_csv' => __('Export to CSV', 'report-manager'),
            'export_json' => __('Export to JSON', 'report-manager'),
            'generate_link' => __('Generate Temporary Link', 'report-manager'),
            'send_email' => __('Send via Email', 'report-manager'),
            
            // Поля форм
            'required_field' => __('This field is required', 'report-manager'),
            'invalid_email' => __('Please enter a valid email address', 'report-manager'),
            'invalid_number' => __('Please enter a valid number', 'report-manager'),
            
            // Даты
            'today' => __('Today', 'report-manager'),
            'yesterday' => __('Yesterday', 'report-manager'),
            'tomorrow' => __('Tomorrow', 'report-manager'),
            'this_week' => __('This Week', 'report-manager'),
            'last_week' => __('Last Week', 'report-manager'),
            'next_week' => __('Next Week', 'report-manager')
        );
    }
    
    /**
     * Смена языка пользователя
     */
    public function ajax_change_language() {
        check_ajax_referer('rm_i18n', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(__('Authentication required', 'report-manager'));
        }
        
        $language = sanitize_text_field($_POST['language']);
        $supported_languages = $this->get_supported_languages();
        
        $valid_locales = array_column($supported_languages, 'wp_locale');
        
        if (!in_array($language, $valid_locales)) {
            wp_send_json_error(__('Invalid language', 'report-manager'));
        }
        
        update_user_meta(get_current_user_id(), 'rm_user_language', $language);
        
        wp_send_json_success(array(
            'message' => __('Language changed successfully', 'report-manager'),
            'language' => $language
        ));
    }
    
    /**
     * Генерация .pot файла
     */
    public function generate_pot_file() {
        // Этот метод может быть использован для автоматической генерации .pot файла
        // В реальном проекте это делается через инструменты вроде wp-cli i18n make-pot
    }
}