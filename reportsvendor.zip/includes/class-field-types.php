<?php

class RM_Field_Types {
    
    public function get_available_types() {
        return array(
            'text' => array(
                'label' => __('Text', 'report-manager'),
                'icon' => 'dashicons-editor-textcolor'
            ),
            'textarea' => array(
                'label' => __('Text Area', 'report-manager'),
                'icon' => 'dashicons-editor-paragraph'
            ),
            'number' => array(
                'label' => __('Number', 'report-manager'),
                'icon' => 'dashicons-editor-ol'
            ),
            'email' => array(
                'label' => __('Email', 'report-manager'),
                'icon' => 'dashicons-email'
            ),
            'date' => array(
                'label' => __('Date', 'report-manager'),
                'icon' => 'dashicons-calendar'
            ),
            'select' => array(
                'label' => __('Dropdown', 'report-manager'),
                'icon' => 'dashicons-arrow-down'
            ),
            'checkbox' => array(
                'label' => __('Checkbox', 'report-manager'),
                'icon' => 'dashicons-yes'
            ),
            'radio' => array(
                'label' => __('Radio Buttons', 'report-manager'),
                'icon' => 'dashicons-marker'
            ),
            'file' => array(
                'label' => __('File Upload', 'report-manager'),
                'icon' => 'dashicons-media-default'
            ),
            'image' => array(
                'label' => __('Image Upload', 'report-manager'),
                'icon' => 'dashicons-format-image'
            ),
            'location' => array(
                'label' => __('Location', 'report-manager'),
                'icon' => 'dashicons-location'
            ),
            'signature' => array(
                'label' => __('Signature', 'report-manager'),
                'icon' => 'dashicons-edit'
            )
        );
    }
    
    /**
     * Рендер поля для админки (редактор шаблонов)
     */
    public function render_field_admin($field, $template_id) {
        $field_types = $this->get_available_types();
        $field_type = $field['type'] ?? 'text';
        
        ob_start();
        ?>
        <div class="rm-field" data-field-type="<?php echo esc_attr($field_type); ?>">
            <div class="rm-field-header">
                <span class="dashicons <?php echo esc_attr($field_types[$field_type]['icon']); ?>"></span>
                <span class="rm-field-label"><?php echo esc_html($field['label'] ?? 'New Field'); ?></span>
                <div class="rm-field-actions">
                    <button type="button" class="rm-field-edit" title="<?php esc_attr_e('Edit', 'report-manager'); ?>">
                        <span class="dashicons dashicons-edit"></span>
                    </button>
                    <button type="button" class="rm-field-delete" title="<?php esc_attr_e('Delete', 'report-manager'); ?>">
                        <span class="dashicons dashicons-trash"></span>
                    </button>
                    <button type="button" class="rm-field-move" title="<?php esc_attr_e('Move', 'report-manager'); ?>">
                        <span class="dashicons dashicons-move"></span>
                    </button>
                </div>
            </div>
            
            <div class="rm-field-settings" style="display: none;">
                <div class="rm-field-setting">
                    <label><?php _e('Field Type', 'report-manager'); ?></label>
                    <select name="field_type" class="rm-field-type-select">
                        <?php foreach ($field_types as $type => $type_data): ?>
                            <option value="<?php echo esc_attr($type); ?>" <?php selected($field_type, $type); ?>>
                                <?php echo esc_html($type_data['label']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="rm-field-setting">
                    <label><?php _e('Field Label', 'report-manager'); ?></label>
                    <input type="text" name="field_label" value="<?php echo esc_attr($field['label'] ?? ''); ?>" 
                           placeholder="<?php esc_attr_e('Enter field label', 'report-manager'); ?>">
                </div>
                
                <div class="rm-field-setting">
                    <label><?php _e('Field Name', 'report-manager'); ?></label>
                    <input type="text" name="field_name" value="<?php echo esc_attr($field['name'] ?? ''); ?>" 
                           placeholder="<?php esc_attr_e('Field name for database', 'report-manager'); ?>">
                </div>
                
                <div class="rm-field-setting">
                    <label>
                        <input type="checkbox" name="field_required" value="1" <?php checked($field['required'] ?? 0, 1); ?>>
                        <?php _e('Required field', 'report-manager'); ?>
                    </label>
                </div>
                
                <!-- Динамические настройки для разных типов полей -->
                <div class="rm-field-type-settings">
                    <?php $this->render_field_type_settings($field_type, $field); ?>
                </div>
                
                <div class="rm-field-actions-bottom">
                    <button type="button" class="button rm-field-save"><?php _e('Save', 'report-manager'); ?></button>
                    <button type="button" class="button rm-field-cancel"><?php _e('Cancel', 'report-manager'); ?></button>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Рендер специфических настроек для типов полей
     */
    private function render_field_type_settings($field_type, $field) {
        switch ($field_type) {
            case 'select':
            case 'radio':
                $options = $field['options'] ?? array('Option 1', 'Option 2');
                ?>
                <div class="rm-field-setting">
                    <label><?php _e('Options', 'report-manager'); ?></label>
                    <div class="rm-field-options">
                        <?php foreach ($options as $index => $option): ?>
                            <div class="rm-field-option">
                                <input type="text" name="field_options[]" 
                                       value="<?php echo esc_attr($option); ?>"
                                       placeholder="<?php esc_attr_e('Option text', 'report-manager'); ?>">
                                <button type="button" class="rm-remove-option">×</button>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <button type="button" class="button rm-add-option"><?php _e('Add Option', 'report-manager'); ?></button>
                </div>
                <?php
                break;
                
            case 'file':
            case 'image':
                ?>
                <div class="rm-field-setting">
                    <label><?php _e('Maximum file size', 'report-manager'); ?></label>
                    <input type="number" name="settings[max_size]" 
                           value="<?php echo esc_attr($field['settings']['max_size'] ?? 5); ?>" min="1" max="20">
                    <span>MB</span>
                </div>
                
                <div class="rm-field-setting">
                    <label><?php _e('Allowed file types', 'report-manager'); ?></label>
                    <div class="rm-file-types">
                        <?php
                        $allowed_types = array(
                            'jpg' => 'JPEG',
                            'jpeg' => 'JPEG', 
                            'png' => 'PNG',
                            'gif' => 'GIF',
                            'pdf' => 'PDF',
                            'doc' => 'DOC',
                            'docx' => 'DOCX'
                        );
                        
                        $selected_types = $field['settings']['allowed_types'] ?? array_keys($allowed_types);
                        
                        foreach ($allowed_types as $ext => $label):
                        ?>
                            <label>
                                <input type="checkbox" name="settings[allowed_types][]" 
                                       value="<?php echo esc_attr($ext); ?>"
                                       <?php checked(in_array($ext, $selected_types)); ?>>
                                <?php echo esc_html($label); ?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php
                break;
                
            case 'location':
                ?>
                <div class="rm-field-setting">
                    <label>
                        <input type="checkbox" name="settings[auto_location]" value="1" 
                               <?php checked($field['settings']['auto_location'] ?? 1, 1); ?>>
                        <?php _e('Automatically detect location', 'report-manager'); ?>
                    </label>
                </div>
                <?php
                break;
        }
    }
    
    /**
     * Рендер поля для фронтенда (заполнение отчета)
     */
    public function render_field_frontend($field, $value = '') {
        $field_name = "rm_field_{$field->field_name}";
        $required = $field->is_required ? 'required' : '';
        
        ob_start();
        
        switch ($field->field_type) {
            case 'text':
            case 'email':
            case 'number':
                ?>
                <div class="rm-form-field">
                    <label for="<?php echo esc_attr($field_name); ?>">
                        <?php echo esc_html($field->field_label); ?>
                        <?php if ($required): ?><span class="required">*</span><?php endif; ?>
                    </label>
                    <input type="<?php echo esc_attr($field->field_type); ?>" 
                           id="<?php echo esc_attr($field_name); ?>"
                           name="<?php echo esc_attr($field_name); ?>" 
                           value="<?php echo esc_attr($value); ?>"
                           <?php echo $required; ?>>
                </div>
                <?php
                break;
                
            case 'textarea':
                ?>
                <div class="rm-form-field">
                    <label for="<?php echo esc_attr($field_name); ?>">
                        <?php echo esc_html($field->field_label); ?>
                        <?php if ($required): ?><span class="required">*</span><?php endif; ?>
                    </label>
                    <textarea id="<?php echo esc_attr($field_name); ?>"
                              name="<?php echo esc_attr($field_name); ?>" 
                              rows="4" <?php echo $required; ?>><?php echo esc_textarea($value); ?></textarea>
                </div>
                <?php
                break;
                
            case 'select':
                ?>
                <div class="rm-form-field">
                    <label for="<?php echo esc_attr($field_name); ?>">
                        <?php echo esc_html($field->field_label); ?>
                        <?php if ($required): ?><span class="required">*</span><?php endif; ?>
                    </label>
                    <select id="<?php echo esc_attr($field_name); ?>"
                            name="<?php echo esc_attr($field_name); ?>" <?php echo $required; ?>>
                        <option value=""><?php _e('-- Select --', 'report-manager'); ?></option>
                        <?php foreach ($field->field_options as $option): ?>
                            <option value="<?php echo esc_attr($option); ?>" 
                                    <?php selected($value, $option); ?>>
                                <?php echo esc_html($option); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php
                break;
                
            case 'image':
                ?>
                <div class="rm-form-field rm-image-upload">
                    <label>
                        <?php echo esc_html($field->field_label); ?>
                        <?php if ($required): ?><span class="required">*</span><?php endif; ?>
                    </label>
                    
                    <div class="rm-image-preview" style="display: <?php echo $value ? 'block' : 'none'; ?>;">
                        <img src="<?php echo esc_attr($value); ?>" alt="Preview">
                        <button type="button" class="rm-remove-image"><?php _e('Remove', 'report-manager'); ?></button>
                    </div>
                    
                    <div class="rm-image-upload-area" style="display: <?php echo $value ? 'none' : 'block'; ?>;">
                        <input type="file" 
                               name="<?php echo esc_attr($field_name); ?>[]" 
                               multiple 
                               accept="image/*"
                               <?php echo $required; ?>>
                        <p class="description"><?php _e('Maximum file size: 5MB', 'report-manager'); ?></p>
                    </div>
                    
                    <input type="hidden" name="<?php echo esc_attr($field_name); ?>_existing" value="<?php echo esc_attr($value); ?>">
                </div>
                <?php
                break;
                
            case 'location':
                ?>
                <div class="rm-form-field rm-location-field">
                    <label>
                        <?php echo esc_html($field->field_label); ?>
                        <?php if ($required): ?><span class="required">*</span><?php endif; ?>
                    </label>
                    
                    <div class="rm-location-inputs">
                        <input type="text" 
                               name="<?php echo esc_attr($field_name); ?>[address]" 
                               value="<?php echo esc_attr($value['address'] ?? ''); ?>"
                               placeholder="<?php esc_attr_e('Enter address', 'report-manager'); ?>"
                               <?php echo $required; ?>>
                        
                        <button type="button" class="button rm-get-location">
                            <?php _e('Get Current Location', 'report-manager'); ?>
                        </button>
                    </div>
                    
                    <input type="hidden" name="<?php echo esc_attr($field_name); ?>[lat]" 
                           value="<?php echo esc_attr($value['lat'] ?? ''); ?>">
                    <input type="hidden" name="<?php echo esc_attr($field_name); ?>[lng]" 
                           value="<?php echo esc_attr($value['lng'] ?? ''); ?>">
                    
                    <div class="rm-location-map" style="display: none;"></div>
                </div>
                <?php
                break;
        }
        
        return ob_get_clean();
    }
}