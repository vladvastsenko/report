<?php

class RM_Templates {
    
    public function __construct() {
        add_action('wp_ajax_rm_save_template', array($this, 'ajax_save_template'));
        add_action('wp_ajax_rm_delete_template', array($this, 'ajax_delete_template'));
        add_action('wp_ajax_rm_clone_template', array($this, 'ajax_clone_template'));
    }
    
    /**
     * Создание нового шаблона
     */
    public function create_template($data) {
        global $wpdb;
        
        $result = $wpdb->insert(
            $wpdb->prefix . 'rm_report_templates',
            array(
                'name' => sanitize_text_field($data['name']),
                'description' => sanitize_textarea_field($data['description']),
                'group_id' => isset($data['group_id']) ? intval($data['group_id']) : 0,
                'created_by' => get_current_user_id(),
                'is_active' => 1,
                'created_at' => current_time('mysql')
            ),
            array('%s', '%s', '%d', '%d', '%d', '%s')
        );
        
        if ($result) {
            return $wpdb->insert_id;
        }
        
        return false;
    }
    
    /**
     * Добавление поля в шаблон
     */
    public function add_template_field($template_id, $field_data) {
        global $wpdb;
        
        $field_types = new RM_Field_Types();
        $valid_types = $field_types->get_available_types();
        
        if (!in_array($field_data['type'], array_keys($valid_types))) {
            return false;
        }
        
        // Получаем максимальный sort_order для этого шаблона
        $max_order = $wpdb->get_var($wpdb->prepare(
            "SELECT MAX(sort_order) FROM {$wpdb->prefix}rm_report_fields WHERE template_id = %d",
            $template_id
        ));
        
        $sort_order = $max_order ? $max_order + 1 : 0;
        
        $result = $wpdb->insert(
            $wpdb->prefix . 'rm_report_fields',
            array(
                'template_id' => $template_id,
                'field_type' => $field_data['type'],
                'field_name' => sanitize_title($field_data['name']),
                'field_label' => sanitize_text_field($field_data['label']),
                'field_options' => isset($field_data['options']) ? serialize($field_data['options']) : '',
                'is_required' => isset($field_data['required']) ? intval($field_data['required']) : 0,
                'sort_order' => $sort_order,
                'settings' => isset($field_data['settings']) ? serialize($field_data['settings']) : ''
            ),
            array('%d', '%s', '%s', '%s', '%s', '%d', '%d', '%s')
        );
        
        return $result ? $wpdb->insert_id : false;
    }
    
    /**
     * Получение шаблонов доступных пользователю
     */
    public function get_available_templates($user_id, $group_id = null) {
        global $wpdb;
        
        $user_groups = array(0); // Глобальные шаблоны
        
        // Получаем группы пользователя
        $groups = $wpdb->get_col($wpdb->prepare(
            "SELECT group_id FROM {$wpdb->prefix}rm_user_groups WHERE user_id = %d",
            $user_id
        ));
        
        $user_groups = array_merge($user_groups, $groups);
        
        $placeholders = implode(',', array_fill(0, count($user_groups), '%d'));
        $sql = "SELECT * FROM {$wpdb->prefix}rm_report_templates 
                WHERE (group_id IN ($placeholders) OR created_by = %d)
                AND is_active = 1 
                ORDER BY group_id DESC, name ASC";
        
        $params = array_merge($user_groups, array($user_id));
        
        return $wpdb->get_results($wpdb->prepare($sql, $params));
    }
    
    /**
     * Получение полей шаблона
     */
    public function get_template_fields($template_id) {
        global $wpdb;
        
        $fields = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}rm_report_fields 
             WHERE template_id = %d 
             ORDER BY sort_order ASC",
            $template_id
        ));
        
        // Десериализуем options и settings
        foreach ($fields as $field) {
            if ($field->field_options) {
                $field->field_options = unserialize($field->field_options);
            }
            if ($field->settings) {
                $field->settings = unserialize($field->settings);
            }
        }
        
        return $fields;
    }
    
    /**
     * Клонирование шаблона
     */
    public function clone_template($template_id, $new_name, $target_group_id = null) {
        global $wpdb;
        
        // Получаем исходный шаблон
        $template = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}rm_report_templates WHERE id = %d",
            $template_id
        ));
        
        if (!$template) {
            return false;
        }
        
        // Создаем новый шаблон
        $new_template_id = $this->create_template(array(
            'name' => $new_name,
            'description' => $template->description,
            'group_id' => $target_group_id ?: $template->group_id
        ));
        
        if (!$new_template_id) {
            return false;
        }
        
        // Клонируем поля
        $fields = $this->get_template_fields($template_id);
        
        foreach ($fields as $field) {
            $this->add_template_field($new_template_id, array(
                'type' => $field->field_type,
                'name' => $field->field_name,
                'label' => $field->field_label,
                'options' => $field->field_options,
                'required' => $field->is_required,
                'settings' => $field->settings
            ));
        }
        
        return $new_template_id;
    }
    
    /**
     * AJAX: Сохранение шаблона
     */
    public function ajax_save_template() {
        check_ajax_referer('rm_manage_templates', 'nonce');
        
        if (!current_user_can('rm_manage_templates')) {
            wp_send_json_error(__('Insufficient permissions', 'report-manager'));
        }
        
        $template_data = array(
            'name' => sanitize_text_field($_POST['name']),
            'description' => sanitize_textarea_field($_POST['description']),
            'group_id' => isset($_POST['group_id']) ? intval($_POST['group_id']) : 0
        );
        
        $template_id = $this->create_template($template_data);
        
        if ($template_id) {
            // Сохраняем поля если есть
            if (!empty($_POST['fields'])) {
                foreach ($_POST['fields'] as $field_data) {
                    $this->add_template_field($template_id, $field_data);
                }
            }
            
            wp_send_json_success(array(
                'message' => __('Template saved successfully', 'report-manager'),
                'template_id' => $template_id
            ));
        } else {
            wp_send_json_error(__('Failed to save template', 'report-manager'));
        }
    }
}