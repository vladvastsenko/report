<?php

class RM_Groups {
    
    public function __construct() {
        add_action('wp_ajax_rm_create_group', array($this, 'ajax_create_group'));
        add_action('wp_ajax_rm_update_group', array($this, 'ajax_update_group'));
        add_action('wp_ajax_rm_delete_group', array($this, 'ajax_delete_group'));
    }
    
    /**
     * Создание новой группы
     */
    public function create_group($name, $super_user_id, $description = '') {
        global $wpdb;
        
        $result = $wpdb->insert(
            $wpdb->prefix . 'rm_groups',
            array(
                'name' => sanitize_text_field($name),
                'description' => sanitize_textarea_field($description),
                'super_user_id' => intval($super_user_id),
                'allow_custom_pdf' => 1,
                'created_at' => current_time('mysql')
            ),
            array('%s', '%s', '%d', '%d', '%s')
        );
        
        if ($result) {
            $group_id = $wpdb->insert_id;
            
            // Добавляем суперпользователя в группу
            $this->add_user_to_group($super_user_id, $group_id, 'super_user');
            
            return $group_id;
        }
        
        return false;
    }
    
    /**
     * Добавление пользователя в группу
     */
    public function add_user_to_group($user_id, $group_id, $role = 'user', $invited_by = null) {
        global $wpdb;
        
        // Проверяем нет ли уже пользователя в группе
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}rm_user_groups 
             WHERE user_id = %d AND group_id = %d",
            $user_id, $group_id
        ));
        
        if ($exists) {
            return false;
        }
        
        $result = $wpdb->insert(
            $wpdb->prefix . 'rm_user_groups',
            array(
                'user_id' => $user_id,
                'group_id' => $group_id,
                'role' => $role,
                'invited_by' => $invited_by,
                'invited_at' => current_time('mysql'),
                'joined_at' => current_time('mysql')
            ),
            array('%d', '%d', '%s', '%d', '%s', '%s')
        );
        
        if ($result) {
            // Обновляем роль пользователя в WordPress
            $user = get_userdata($user_id);
            if ($role === 'super_user') {
                $user->add_role('rm_super_user');
            } else {
                $user->add_role('rm_group_user');
            }
            
            return true;
        }
        
        return false;
    }
    
    /**
     * Получение групп пользователя
     */
    public function get_user_groups($user_id, $role = null) {
        global $wpdb;
        
        $sql = "SELECT g.*, ug.role, ug.joined_at 
                FROM {$wpdb->prefix}rm_groups g
                INNER JOIN {$wpdb->prefix}rm_user_groups ug ON g.id = ug.group_id
                WHERE ug.user_id = %d";
        
        $params = array($user_id);
        
        if ($role) {
            $sql .= " AND ug.role = %s";
            $params[] = $role;
        }
        
        $sql .= " ORDER BY g.name ASC";
        
        return $wpdb->get_results($wpdb->prepare($sql, $params));
    }
    
    /**
     * Получение пользователей группы
     */
    public function get_group_users($group_id, $role = null) {
        global $wpdb;
        
        $sql = "SELECT u.ID, u.display_name, u.user_email, ug.role, ug.joined_at, ug.invited_by
                FROM {$wpdb->users} u
                INNER JOIN {$wpdb->prefix}rm_user_groups ug ON u.ID = ug.user_id
                WHERE ug.group_id = %d";
        
        $params = array($group_id);
        
        if ($role) {
            $sql .= " AND ug.role = %s";
            $params[] = $role;
        }
        
        $sql .= " ORDER BY ug.role DESC, u.display_name ASC";
        
        return $wpdb->get_results($wpdb->prepare($sql, $params));
    }
    
    /**
     * Проверка является ли пользователь суперпользователем группы
     */
    public function is_group_super_user($user_id, $group_id) {
        global $wpdb;
        
        $role = $wpdb->get_var($wpdb->prepare(
            "SELECT role FROM {$wpdb->prefix}rm_user_groups 
             WHERE user_id = %d AND group_id = %d",
            $user_id, $group_id
        ));
        
        return $role === 'super_user';
    }
    
    /**
     * Назначение суперпользователя в группе
     */
    public function promote_to_super_user($user_id, $group_id) {
        global $wpdb;
        
        $result = $wpdb->update(
            $wpdb->prefix . 'rm_user_groups',
            array('role' => 'super_user'),
            array('user_id' => $user_id, 'group_id' => $group_id),
            array('%s'),
            array('%d', '%d')
        );
        
        if ($result) {
            $user = get_userdata($user_id);
            $user->add_role('rm_super_user');
            return true;
        }
        
        return false;
    }
    
    /**
     * AJAX: Создание группы
     */
    public function ajax_create_group() {
        check_ajax_referer('rm_manage_groups', 'nonce');
        
        if (!current_user_can('rm_super_user')) {
            wp_die(__('Insufficient permissions', 'report-manager'));
        }
        
        $name = sanitize_text_field($_POST['name']);
        $description = sanitize_textarea_field($_POST['description']);
        $user_id = get_current_user_id();
        
        if (empty($name)) {
            wp_send_json_error(__('Group name is required', 'report-manager'));
        }
        
        $group_id = $this->create_group($name, $user_id, $description);
        
        if ($group_id) {
            wp_send_json_success(array(
                'message' => __('Group created successfully', 'report-manager'),
                'group_id' => $group_id
            ));
        } else {
            wp_send_json_error(__('Failed to create group', 'report-manager'));
        }
    }
}