<?php

class RM_Email_Handler {
    
    public function __construct() {
        add_action('wp_ajax_rm_send_report_email', array($this, 'ajax_send_report_email'));
    }
    
    /**
     * Отправка отчета по email
     */
    public function send_report_email($report_id, $email_data) {
        $report = get_post($report_id);
        
        if (!$report || $report->post_type !== 'rm_report') {
            return false;
        }
        
        // Генерируем PDF если нужно
        $attachments = array();
        if ($email_data['attach_pdf'] ?? false) {
            $pdf_generator = new RM_PDF_Generator();
            $pdf_data = $pdf_generator->generate_report_pdf($report_id);
            
            if ($pdf_data) {
                $attachments[] = $pdf_data['filepath'];
            }
        }
        
        // Подготавливаем данные email
        $subject = $this->prepare_subject($email_data['subject'], $report);
        $message = $this->prepare_message($email_data['message'], $report);
        $to = $this->validate_emails($email_data['to']);
        
        if (empty($to)) {
            return false;
        }
        
        // Отправляем email
        $headers = array('Content-Type: text/html; charset=UTF-8');
        
        if ($email_data['cc'] ?? '') {
            $cc_emails = $this->validate_emails($email_data['cc']);
            foreach ($cc_emails as $cc_email) {
                $headers[] = "Cc: $cc_email";
            }
        }
        
        $sent = wp_mail($to, $subject, $message, $headers, $attachments);
        
        // Очищаем временные файлы
        foreach ($attachments as $attachment) {
            if (file_exists($attachment)) {
                unlink($attachment);
            }
        }
        
        // Логируем отправку
        if ($sent) {
            $this->log_email_sent($report_id, $to, $email_data['cc'] ?? '');
        }
        
        return $sent;
    }
    
    /**
     * Подготовка темы письма
     */
    private function prepare_subject($subject, $report) {
        $replacements = array(
            '{{report_title}}' => $report->post_title,
            '{{report_date}}' => date_i18n(get_option('date_format'), strtotime($report->post_date)),
            '{{site_name}}' => get_bloginfo('name')
        );
        
        return str_replace(array_keys($replacements), array_values($replacements), $subject);
    }
    
    /**
     * Подготовка тела письма
     */
    private function prepare_message($message, $report) {
        $report_url = get_permalink($report->ID);
        $author_name = get_the_author_meta('display_name', $report->post_author);
        
        $replacements = array(
            '{{report_title}}' => $report->post_title,
            '{{report_date}}' => date_i18n(get_option('date_format'), strtotime($report->post_date)),
            '{{report_url}}' => $report_url,
            '{{author_name}}' => $author_name,
            '{{site_name}}' => get_bloginfo('name'),
            '{{site_url}}' => home_url()
        );
        
        $message = str_replace(array_keys($replacements), array_values($replacements), $message);
        
        // Оборачиваем в HTML шаблон
        return $this->wrap_in_html_template($message);
    }
    
    /**
     * Обертка сообщения в HTML шаблон
     */
    private function wrap_in_html_template($message) {
        ob_start();
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .email-container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .email-header { border-bottom: 2px solid #0073aa; padding-bottom: 10px; margin-bottom: 20px; }
                .email-footer { margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 12px; color: #666; }
            </style>
        </head>
        <body>
            <div class="email-container">
                <div class="email-header">
                    <h1><?php echo get_bloginfo('name'); ?></h1>
                </div>
                
                <div class="email-content">
                    <?php echo wpautop($message); ?>
                </div>
                
                <div class="email-footer">
                    <p><?php _e('This email was sent from the report management system.', 'report-manager'); ?></p>
                </div>
            </div>
        </body>
        </html>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Валидация email адресов
     */
    private function validate_emails($emails) {
        $email_list = is_array($emails) ? $emails : explode(',', $emails);
        $valid_emails = array();
        
        foreach ($email_list as $email) {
            $email = sanitize_email(trim($email));
            if (is_email($email)) {
                $valid_emails[] = $email;
            }
        }
        
        return $valid_emails;
    }
    
    /**
     * Логирование отправки email
     */
    private function log_email_sent($report_id, $to, $cc) {
        $log_entry = array(
            'report_id' => $report_id,
            'sent_to' => $to,
            'cc' => $cc,
            'sent_by' => get_current_user_id(),
            'sent_at' => current_time('mysql')
        );
        
        $logs = get_post_meta($report_id, '_rm_email_logs', true);
        if (!is_array($logs)) {
            $logs = array();
        }
        
        $logs[] = $log_entry;
        update_post_meta($report_id, '_rm_email_logs', $logs);
    }
    
    /**
     * AJAX: Отправка отчета по email
     */
    public function ajax_send_report_email() {
        check_ajax_referer('rm_frontend_actions', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error(__('Authentication required', 'report-manager'));
        }
        
        $report_id = intval($_POST['report_id']);
        $email_data = array(
            'to' => $_POST['to_emails'],
            'cc' => $_POST['cc_emails'] ?? '',
            'subject' => sanitize_text_field($_POST['subject']),
            'message' => wp_kses_post($_POST['message']),
            'attach_pdf' => isset($_POST['attach_pdf']) && $_POST['attach_pdf'] === 'true'
        );
        
        if (!$this->user_can_email_report(get_current_user_id(), $report_id)) {
            wp_send_json_error(__('Permission denied', 'report-manager'));
        }
        
        $result = $this->send_report_email($report_id, $email_data);
        
        if ($result) {
            wp_send_json_success(__('Email sent successfully', 'report-manager'));
        } else {
            wp_send_json_error(__('Failed to send email', 'report-manager'));
        }
    }
    
    /**
     * Проверка прав на отправку email
     */
    private function user_can_email_report($user_id, $report_id) {
        return $this->user_can_export_report($user_id, $report_id); // Та же логика что и для экспорта
    }
}