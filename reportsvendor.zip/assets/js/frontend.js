(function($) {
    'use strict';

    class ReportManagerFrontend {
        constructor() {
            this.init();
        }

        init() {
            this.bindEvents();
        }

        bindEvents() {
            // Сохранение отчета
            $(document).on('click', '#rm-save-draft', () => this.saveReport('draft'));
            
            // Загрузка шаблона
            $(document).on('change', '#rm-template-select', (e) => this.loadTemplate(e.target.value));
            
            // Добавление кастомных полей
            $(document).on('click', '.rm-field-type', (e) => this.addCustomField($(e.target).data('type')));
            
            // Удаление полей
            $(document).on('click', '.rm-remove-field', (e) => this.removeField(e));
            
            // Drag and drop для полей
            this.initSortable();
        }

        saveReport(status = 'draft') {
            const formData = new FormData($('#rm-report-form')[0]);
            formData.append('action', 'rm_save_report');
            formData.append('status', status);

            $.ajax({
                url: rm_frontend.ajax_url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: (response) => {
                    if (response.success) {
                        this.showMessage(response.data.message, 'success');
                        if (response.data.redirect_url) {
                            setTimeout(() => {
                                window.location.href = response.data.redirect_url;
                            }, 1000);
                        }
                    } else {
                        this.showMessage(response.data, 'error');
                    }
                },
                error: () => {
                    this.showMessage(rm_frontend.i18n.error, 'error');
                }
            });
        }

        loadTemplate(templateId) {
            if (!templateId) return;

            $.ajax({
                url: rm_frontend.ajax_url,
                type: 'POST',
                data: {
                    action: 'rm_load_template',
                    template_id: templateId,
                    nonce: rm_frontend.nonce
                },
                success: (response) => {
                    if (response.success) {
                        $('#rm-form-fields').html(response.data.html);
                        this.showMessage(`Template loaded with ${response.data.fields_count} fields`, 'success');
                    } else {
                        this.showMessage('Failed to load template', 'error');
                    }
                }
            });
        }

        addCustomField(fieldType) {
            const fieldHtml = this.generateFieldHtml(fieldType);
            $('#rm-form-fields .rm-no-fields').remove();
            $('#rm-form-fields').append(fieldHtml);
        }

        generateFieldHtml(fieldType) {
            const fieldId = 'field_' + Date.now();
            
            const templates = {
                text: `
                    <div class="rm-custom-field" data-field-type="${fieldType}">
                        <div class="rm-field-header">
                            <input type="text" placeholder="Field Label" class="rm-field-label">
                            <button type="button" class="rm-remove-field">×</button>
                        </div>
                        <input type="text" name="rm_field_${fieldId}" placeholder="Enter text">
                    </div>
                `,
                textarea: `
                    <div class="rm-custom-field" data-field-type="${fieldType}">
                        <div class="rm-field-header">
                            <input type="text" placeholder="Field Label" class="rm-field-label">
                            <button type="button" class="rm-remove-field">×</button>
                        </div>
                        <textarea name="rm_field_${fieldId}" placeholder="Enter text" rows="4"></textarea>
                    </div>
                `,
                number: `
                    <div class="rm-custom-field" data-field-type="${fieldType}">
                        <div class="rm-field-header">
                            <input type="text" placeholder="Field Label" class="rm-field-label">
                            <button type="button" class="rm-remove-field">×</button>
                        </div>
                        <input type="number" name="rm_field_${fieldId}" placeholder="Enter number">
                    </div>
                `
            };

            return templates[fieldType] || templates.text;
        }

        removeField(e) {
            $(e.target).closest('.rm-custom-field').remove();
        }

        initSortable() {
            $('#rm-form-fields').sortable({
                handle: '.rm-field-header',
                placeholder: 'rm-field-placeholder',
                update: () => this.updateFieldOrder()
            });
        }

        updateFieldOrder() {
            // Логика обновления порядка полей
            console.log('Field order updated');
        }

        showMessage(message, type = 'info') {
            const messageClass = `rm-message rm-message-${type}`;
            const $message = $(`<div class="${messageClass}">${message}</div>`);
            
            $('.rm-dashboard, .rm-report-builder').prepend($message);
            
            setTimeout(() => {
                $message.fadeOut(() => $message.remove());
            }, 3000);
        }
    }

    // Инициализация когда DOM готов
    $(document).ready(() => {
        new ReportManagerFrontend();
    });

})(jQuery);